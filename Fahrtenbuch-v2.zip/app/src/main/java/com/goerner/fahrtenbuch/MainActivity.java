package com.goerner.fahrtenbuch;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Consumer;

public class MainActivity extends Activity {
    static final int REQ_PERM = 1, REQ_RESTORE = 2;
    static final int C_BG = 0xFFF2F4F7, C_PRIMARY = 0xFF1F3A5F, C_GREEN = 0xFF2E7D32, C_RED = 0xFFC62828,
            C_GREY = 0xFF8A94A3, C_TEXT = 0xFF1A1A1A, C_SUB = 0xFF5F6B7A, C_YELLOW = 0xFFFFF3C4, C_WHITE = 0xFFFFFFFF;

    private Button bigBtn;
    private TextView status, msg, hint, monthLabel, summary, subTitle;
    private LinearLayout list;
    private final Handler h = new Handler(Looper.getMainLooper());
    private long stamp = -1, lastHint = 0;
    private int year, month;
    private final Locale DE = Locale.GERMANY;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateStatus();
            if (Store.fileStamp(MainActivity.this) != stamp) refreshList();
            if (System.currentTimeMillis() - lastHint > 60_000L) updateHint();
            h.postDelayed(this, 1000);
        }
    };

    // ======================= Aufbau =======================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(C_PRIMARY);
        Calendar now = Calendar.getInstance();
        year = now.get(Calendar.YEAR);
        month = now.get(Calendar.MONTH);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(C_BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(32));
        sv.addView(root);

        TextView title = text("Fahrtenbuch", 26, C_PRIMARY, true);
        root.addView(title);
        subTitle = text("", 14, C_SUB, false);
        root.addView(subTitle);

        bigBtn = new Button(this);
        bigBtn.setAllCaps(false);
        bigBtn.setTextSize(34);
        bigBtn.setTypeface(Typeface.DEFAULT_BOLD);
        bigBtn.setTextColor(C_WHITE);
        bigBtn.setOnClickListener(v -> onBig());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170));
        bp.topMargin = dp(16);
        root.addView(bigBtn, bp);

        status = text("", 16, C_TEXT, true);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(12), 0, dp(4));
        root.addView(status);

        msg = text("", 13, C_GREEN, false);
        msg.setGravity(Gravity.CENTER);
        root.addView(msg);

        hint = text("", 14, C_TEXT, false);
        hint.setPadding(dp(14), dp(12), dp(14), dp(12));
        hint.setBackground(round(C_WHITE, 12));
        hint.setOnClickListener(v -> {
            if (!CalendarHelper.allowed(this)) askPermissions();
            else { lastHint = 0; updateHint(); }
        });
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = dp(12);
        root.addView(hint, hp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button exp = smallBtn("Export (Excel)", C_PRIMARY);
        exp.setOnClickListener(v -> exportDialog());
        Button set = smallBtn("Einstellungen", C_SUB);
        set.setOnClickListener(v -> settingsDialog());
        LinearLayout.LayoutParams w1 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        w1.rightMargin = dp(6);
        LinearLayout.LayoutParams w2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        w2.leftMargin = dp(6);
        row.addView(exp, w1);
        row.addView(set, w2);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(12);
        root.addView(row, rp);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        Button prev = smallBtn("◀", C_PRIMARY);
        prev.setOnClickListener(v -> moveMonth(-1));
        Button next = smallBtn("▶", C_PRIMARY);
        next.setOnClickListener(v -> moveMonth(1));
        monthLabel = text("", 18, C_PRIMARY, true);
        monthLabel.setGravity(Gravity.CENTER);
        nav.addView(prev, new LinearLayout.LayoutParams(dp(56), dp(44)));
        nav.addView(monthLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        nav.addView(next, new LinearLayout.LayoutParams(dp(56), dp(44)));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        np.topMargin = dp(20);
        root.addView(nav, np);

        summary = text("", 13, C_SUB, false);
        summary.setGravity(Gravity.CENTER);
        summary.setPadding(0, dp(6), 0, dp(10));
        root.addView(summary);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        TextView help = text("Tippen = Fahrt bearbeiten · Lange drücken = stornieren", 12, C_GREY, false);
        help.setGravity(Gravity.CENTER);
        help.setPadding(0, dp(8), 0, 0);
        root.addView(help);

        setContentView(sv);

        askPermissions();
        if (!Store.p(this).getBoolean("welcomed", false)) welcome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumeIfNeeded();
        subTitle.setText(vehicleLine());
        lastHint = 0;
        refreshList();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }

    // ======================= Start / Stopp =======================

    private void onBig() {
        SharedPreferences p = Store.p(this);
        if (p.getBoolean("active", false)) {
            startService(new Intent(this, TrackingService.class).setAction(TrackingService.ACTION_STOP));
            status.setText("Fahrt wird gespeichert …");
            return;
        }
        if (p.getBoolean("finishing", false)) {
            toast("Die letzte Fahrt wird noch gespeichert …");
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            toast("Bitte Standort erlauben – sonst können keine km gezählt werden.");
            askPermissions();
            return;
        }
        if (Double.isNaN(Store.kmPrecise(this))) {
            askKm(this::startTrip);
            return;
        }
        startTrip();
    }

    private void startTrip() {
        Store.p(this).edit().remove("lastMsg").apply();
        startForegroundService(new Intent(this, TrackingService.class).setAction(TrackingService.ACTION_START));
        h.postDelayed(this::updateStatus, 300);
    }

    /** Falls die App/der Dienst unterwegs beendet wurde: Fahrt weiterzählen. */
    private void resumeIfNeeded() {
        SharedPreferences p = Store.p(this);
        if (p.getBoolean("active", false) && !TrackingService.running
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                startForegroundService(new Intent(this, TrackingService.class).setAction(TrackingService.ACTION_RESUME));
            } catch (Exception ignored) { }
        }
    }

    private void updateStatus() {
        SharedPreferences p = Store.p(this);
        boolean active = p.getBoolean("active", false), fin = p.getBoolean("finishing", false);
        if (active) {
            bigBtn.setText("STOPP");
            bigBtn.setBackground(round(C_RED, 28));
            long t0 = p.getLong("tStart", System.currentTimeMillis());
            long min = (System.currentTimeMillis() - t0) / 60_000L;
            float km = p.getFloat("dist", 0f) / 1000f;
            status.setText(String.format(DE, "Fahrt läuft seit %s Uhr · %.1f km · %d:%02d h",
                    hm(t0), km, min / 60, min % 60));
        } else if (fin) {
            bigBtn.setText("…");
            bigBtn.setBackground(round(C_GREY, 28));
            status.setText("Fahrt wird gespeichert …");
        } else {
            bigBtn.setText("START");
            bigBtn.setBackground(round(C_GREEN, 28));
            double km = Store.kmPrecise(this);
            status.setText(Double.isNaN(km) ? "Bereit – beim ersten Start wird der Kilometerstand abgefragt"
                    : "Bereit · Kilometerstand " + num(Math.round(km)));
        }
        String m = p.getString("lastMsg", "");
        msg.setText(m);
        msg.setTextColor(m.startsWith("Fehler") ? C_RED : C_GREEN);
        msg.setVisibility(m.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void updateHint() {
        lastHint = System.currentTimeMillis();
        if (!CalendarHelper.allowed(this)) {
            hint.setText("Kalender ist nicht freigegeben – hier tippen, um ihn zu erlauben.");
            return;
        }
        long now = System.currentTimeMillis();
        List<Matcher.Ev> evs = CalendarHelper.events(this, now - 30 * 60_000L, now + 12 * 3600_000L);
        Matcher.Ev next = null;
        for (Matcher.Ev e : evs) {
            if (e.allDay || e.end <= now) continue;
            if (next == null || (next.location.trim().isEmpty() && !e.location.trim().isEmpty() && e.begin - next.begin < 3600_000L))
                next = e;
            if (!next.location.trim().isEmpty()) break;
        }
        if (next == null) {
            hint.setText("Keine Termine in den nächsten 12 Stunden.\nOhne Termin trägt die App die GPS-Adresse ein.");
        } else {
            String loc = next.location.trim().isEmpty() ? "(kein Ort im Termin eingetragen)" : next.location.trim();
            hint.setText("Nächster Termin: " + hm(next.begin) + " Uhr · " + next.title + "\n" + loc);
        }
    }

    // ======================= Liste =======================

    private void moveMonth(int d) {
        month += d;
        if (month < 0) { month = 11; year--; }
        if (month > 11) { month = 0; year++; }
        refreshList();
    }

    private void refreshList() {
        stamp = Store.fileStamp(this);
        List<Trip> all = Store.load(this);
        Trip latest = Store.last(all);
        Calendar c = Calendar.getInstance();
        c.set(year, month, 1, 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        long from = c.getTimeInMillis();
        c.add(Calendar.MONTH, 1);
        long to = c.getTimeInMillis();
        monthLabel.setText(new SimpleDateFormat("MMMM yyyy", DE).format(new Date(from)));

        list.removeAllViews();
        long sum = 0, g = 0, pr = 0, wa = 0;
        int open = 0, n = 0;
        for (int i = all.size() - 1; i >= 0; i--) {
            Trip t = all.get(i);
            if (t.start < from || t.start >= to) continue;
            n++;
            if (!t.storniert) {
                sum += t.km();
                if (Trip.GESCHAEFTLICH.equals(t.art)) g += t.km();
                else if (Trip.PRIVAT.equals(t.art)) pr += t.km();
                else if (Trip.WOHNUNG_ARBEIT.equals(t.art)) wa += t.km();
                else open++;
            }
            list.addView(card(t, latest != null && latest.id == t.id));
        }
        if (n == 0) {
            TextView e = text("Noch keine Fahrten in diesem Monat.", 14, C_GREY, false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, dp(20), 0, dp(20));
            list.addView(e);
            summary.setText("");
        } else {
            String s = n + " Fahrten · " + num(sum) + " km  (geschäftlich " + num(g) + " · privat " + num(pr)
                    + " · Wohnung–Arbeit " + num(wa) + ")";
            if (open > 0) s += "\n⚠ " + open + " Fahrt(en) noch prüfen (gelb)";
            summary.setText(s);
        }
    }

    private View card(Trip t, boolean latest) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        boolean check = Trip.PRUEFEN.equals(t.art) && !t.storniert;
        card.setBackground(round(check ? C_YELLOW : C_WHITE, 12));

        SimpleDateFormat d = new SimpleDateFormat("EE dd.MM.", DE);
        TextView l1 = text((t.storniert ? "STORNIERT · " : "") + d.format(new Date(t.start)) + "  "
                + hm(t.start) + "–" + hm(t.end) + "  ·  " + num(t.km()) + " km", 15, C_TEXT, true);
        card.addView(l1);
        TextView l2 = text(t.startOrt + "  →  " + t.ziel, 14, C_TEXT, false);
        l2.setPadding(0, dp(4), 0, 0);
        card.addView(l2);
        StringBuilder sb = new StringBuilder();
        if (!t.zweck.isEmpty()) sb.append("Zweck: ").append(t.zweck);
        if (!t.partner.isEmpty()) sb.append(sb.length() > 0 ? "\n" : "").append("Partner: ").append(t.partner);
        if (sb.length() > 0) {
            TextView l3 = text(sb.toString(), 13, C_SUB, false);
            l3.setPadding(0, dp(4), 0, 0);
            card.addView(l3);
        }
        int artColor = Trip.GESCHAEFTLICH.equals(t.art) ? C_PRIMARY : Trip.PRIVAT.equals(t.art) ? 0xFF6A1B9A
                : Trip.WOHNUNG_ARBEIT.equals(t.art) ? 0xFF00695C : 0xFFB26A00;
        TextView l4 = text(t.art + "  ·  Km " + num(t.kmStart) + " → " + num(t.kmEnd)
                + (t.termin.isEmpty() ? "" : "  ·  Termin: " + t.termin)
                + (t.log.size() > 1 ? "  ·  geändert" : ""), 12, artColor, true);
        l4.setPadding(0, dp(6), 0, 0);
        card.addView(l4);

        if (t.storniert) {
            card.setAlpha(0.5f);
            l2.setPaintFlags(l2.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
        card.setOnClickListener(v -> editDialog(t, latest));
        card.setOnLongClickListener(v -> {
            stornoDialog(t);
            return true;
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        card.setLayoutParams(lp);
        return card;
    }

    // ======================= Bearbeiten =======================

    private void editDialog(Trip t, boolean latest) {
        LinearLayout f = form();
        EditText eStart = field(f, "Startort", t.startOrt);
        EditText eZiel = field(f, "Reiseziel", t.ziel);
        EditText eZweck = field(f, "Reisezweck", t.zweck);
        EditText ePartner = field(f, "Geschäftspartner", t.partner);
        f.addView(label("Fahrtart"));
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Trip.ARTEN));
        for (int i = 0; i < Trip.ARTEN.length; i++) if (Trip.ARTEN[i].equals(t.art)) sp.setSelection(i);
        f.addView(sp);
        EditText eKm = field(f, latest ? "Km-Stand Ende (Tacho)" : "Km-Stand Ende (nur bei der letzten Fahrt änderbar)",
                String.valueOf(t.kmEnd));
        eKm.setInputType(InputType.TYPE_CLASS_NUMBER);
        eKm.setEnabled(latest && !t.storniert);

        StringBuilder info = new StringBuilder();
        info.append(String.format(DE, "GPS gemessen: %.1f km", t.gpsKm));
        if (!t.zielGps.isEmpty()) info.append("\nPosition am Ziel: ").append(t.zielGps);
        if (!t.termin.isEmpty()) info.append("\nKalendertermin: ").append(t.termin);
        info.append("\n\nProtokoll:");
        for (String s : t.log) info.append("\n• ").append(s);
        TextView ti = text(info.toString(), 12, C_SUB, false);
        ti.setPadding(0, dp(12), 0, 0);
        f.addView(ti);

        new AlertDialog.Builder(this)
                .setTitle("Fahrt Nr. " + t.nr)
                .setView(scroll(f))
                .setPositiveButton("Speichern", (d, w) -> {
                    List<String> ch = new ArrayList<>();
                    t.startOrt = chg(ch, "Startort", t.startOrt, eStart);
                    t.ziel = chg(ch, "Ziel", t.ziel, eZiel);
                    t.zweck = chg(ch, "Zweck", t.zweck, eZweck);
                    t.partner = chg(ch, "Partner", t.partner, ePartner);
                    String art = Trip.ARTEN[sp.getSelectedItemPosition()];
                    if (!art.equals(t.art)) {
                        ch.add("Fahrtart: " + t.art + " → " + art);
                        t.art = art;
                    }
                    if (latest && !t.storniert) {
                        try {
                            long km = Long.parseLong(eKm.getText().toString().trim());
                            if (km != t.kmEnd) {
                                if (km < t.kmStart) {
                                    toast("Km-Stand Ende darf nicht kleiner als der Beginn sein.");
                                } else {
                                    ch.add("Km-Stand Ende: " + t.kmEnd + " → " + km);
                                    t.kmEnd = km;
                                    Store.setKmPrecise(this, km);
                                }
                            }
                        } catch (NumberFormatException ignored) { }
                    }
                    if (!ch.isEmpty()) {
                        t.log.add(nowStamp() + ": " + String.join("; ", ch));
                        save(t);
                    }
                })
                .setNeutralButton("Termin zuordnen", (d, w) -> chooseEvent(t))
                .setNegativeButton("Abbrechen", null)
                .show();
    }

    private String chg(List<String> ch, String name, String old, EditText e) {
        String v = e.getText().toString().trim();
        if (!v.equals(old)) ch.add(name + ": \"" + old + "\" → \"" + v + "\"");
        return v;
    }

    private void chooseEvent(Trip t) {
        if (!CalendarHelper.allowed(this)) {
            askPermissions();
            return;
        }
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t.start);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long day0 = c.getTimeInMillis();
        List<Matcher.Ev> evs = new ArrayList<>();
        for (Matcher.Ev e : CalendarHelper.events(this, day0, day0 + 24 * 3600_000L)) if (!e.allDay) evs.add(e);
        if (evs.isEmpty()) {
            toast("Keine Termine an diesem Tag gefunden.");
            return;
        }
        String[] items = new String[evs.size()];
        for (int i = 0; i < evs.size(); i++) {
            Matcher.Ev e = evs.get(i);
            items[i] = hm(e.begin) + "  " + e.title + (e.location.trim().isEmpty() ? "" : "\n" + e.location.trim());
        }
        new AlertDialog.Builder(this)
                .setTitle("Welcher Termin war das Ziel?")
                .setItems(items, (d, w) -> {
                    Matcher.Ev e = evs.get(w);
                    List<String> ch = new ArrayList<>();
                    String loc = e.location.trim();
                    if (!loc.isEmpty() && !loc.equals(t.ziel)) { ch.add("Ziel: \"" + t.ziel + "\" → \"" + loc + "\""); t.ziel = loc; }
                    if (!e.title.trim().equals(t.zweck)) { ch.add("Zweck: \"" + t.zweck + "\" → \"" + e.title.trim() + "\""); t.zweck = e.title.trim(); }
                    String partner = CalendarHelper.partner(this, e.id);
                    if (!partner.isEmpty() && !partner.equals(t.partner)) { ch.add("Partner → \"" + partner + "\""); t.partner = partner; }
                    if (!Trip.GESCHAEFTLICH.equals(t.art)) { ch.add("Fahrtart: " + t.art + " → " + Trip.GESCHAEFTLICH); t.art = Trip.GESCHAEFTLICH; }
                    t.termin = e.title.trim() + " (" + hm(e.begin) + " Uhr)";
                    t.log.add(nowStamp() + ": Termin von Hand zugeordnet" + (ch.isEmpty() ? "" : " – " + String.join("; ", ch)));
                    save(t);
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }

    private void stornoDialog(Trip t) {
        if (t.storniert) {
            new AlertDialog.Builder(this)
                    .setTitle("Storno aufheben?")
                    .setMessage("Fahrt Nr. " + t.nr + " wieder mitzählen?")
                    .setPositiveButton("Ja", (d, w) -> {
                        t.storniert = false;
                        t.log.add(nowStamp() + ": Storno aufgehoben");
                        save(t);
                    })
                    .setNegativeButton("Nein", null).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Fahrt Nr. " + t.nr + " stornieren?")
                .setMessage("Nur für versehentliche Einträge (z. B. Start aus Versehen gedrückt). Die Fahrt bleibt "
                        + "durchgestrichen sichtbar und wird nicht mitgezählt. Gelöscht wird nichts.")
                .setPositiveButton("Stornieren", (d, w) -> {
                    t.storniert = true;
                    t.log.add(nowStamp() + ": storniert");
                    save(t);
                })
                .setNegativeButton("Abbrechen", null).show();
    }

    private void save(Trip t) {
        try {
            Store.update(this, t);
            toast("Gespeichert");
        } catch (Exception e) {
            toast("Fehler beim Speichern: " + e.getMessage());
        }
        refreshList();
    }

    // ======================= Export =======================

    private void exportDialog() {
        String m = new SimpleDateFormat("MMMM yyyy", DE).format(monthStart(year, month));
        String[] items = {"Excel · Monat " + m, "Excel · Ganzes Jahr " + year + " (für Steuerberater)",
                "Excel · Alle Fahrten", "Rohdaten als CSV (" + m + ")"};
        new AlertDialog.Builder(this)
                .setTitle("Fahrtenbuch exportieren")
                .setItems(items, (d, w) -> {
                    long from, to;
                    String titel;
                    if (w == 0 || w == 3) {
                        from = monthStart(year, month).getTime();
                        to = month == 11 ? monthStart(year + 1, 0).getTime() : monthStart(year, month + 1).getTime();
                        titel = m;
                    } else if (w == 1) {
                        from = monthStart(year, 0).getTime();
                        to = monthStart(year + 1, 0).getTime();
                        titel = String.valueOf(year);
                    } else {
                        from = Long.MIN_VALUE;
                        to = Long.MAX_VALUE;
                        titel = "gesamt";
                    }
                    List<Trip> sel = new ArrayList<>();
                    int open = 0;
                    for (Trip t : Store.load(this)) {
                        if (t.start >= from && t.start < to) {
                            sel.add(t);
                            if (!t.storniert && Trip.PRUEFEN.equals(t.art)) open++;
                        }
                    }
                    if (sel.isEmpty()) {
                        toast("Keine Fahrten in diesem Zeitraum.");
                        return;
                    }
                    boolean csv = w == 3;
                    if (open > 0 && !csv) {
                        new AlertDialog.Builder(this)
                                .setTitle(open + " Fahrt(en) noch ohne Fahrtart")
                                .setMessage("Diese Fahrten sind gelb markiert. Für den Steuerberater sollten alle Fahrten "
                                        + "zugeordnet sein (geschäftlich, privat oder Wohnung–Arbeit).")
                                .setPositiveButton("Trotzdem exportieren", (d2, w2) -> runExport(sel, titel, false))
                                .setNegativeButton("Erst zuordnen", null).show();
                    } else {
                        runExport(sel, titel, csv);
                    }
                })
                .setNegativeButton("Abbrechen", null).show();
    }

    private void runExport(List<Trip> sel, String titel, boolean csv) {
        toast("Export wird erstellt …");
        new Thread(() -> {
            try {
                Uri u = csv ? Export.exportCsv(this, sel, titel) : Export.exportXlsx(this, sel, titel);
                runOnUiThread(() -> {
                    toast("Gespeichert in Download/Fahrtenbuch");
                    share(u, csv ? "text/csv" : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "Fahrtenbuch " + titel);
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("Export fehlgeschlagen: " + e.getMessage()));
            }
        }).start();
    }

    private void share(Uri u, String mime, String subject) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_STREAM, u);
        i.putExtra(Intent.EXTRA_SUBJECT, subject);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, "Teilen / an PC schicken"));
        } catch (Exception ignored) { }
    }

    // ======================= Einstellungen =======================

    private void settingsDialog() {
        String home = Store.placeAddr(this, "home"), office = Store.placeAddr(this, "office");
        Set<String> cals = Store.calendars(this);
        String[] items = {
                "Kilometerstand eingeben / korrigieren",
                "Zuhause festlegen" + (home.isEmpty() ? " (fehlt)" : "\n" + home),
                "Büro / Arbeitsstätte festlegen" + (office.isEmpty() ? " (optional)" : "\n" + office),
                "Kalender auswählen" + (cals.isEmpty() ? " (alle)" : " (" + cals.size() + " gewählt)"),
                "Fahrzeug & Fahrer",
                "Akku: App nicht einschränken (wichtig bei Samsung)",
                "Backup speichern",
                "Backup laden",
                "Berechtigungen erneut anfragen"
        };
        new AlertDialog.Builder(this)
                .setTitle("Einstellungen")
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0: askKm(null); break;
                        case 1: placeDialog("home", "Zuhause"); break;
                        case 2: placeDialog("office", "Büro / Arbeitsstätte"); break;
                        case 3: calendarDialog(); break;
                        case 4: vehicleDialog(); break;
                        case 5: batterySettings(); break;
                        case 6: backup(); break;
                        case 7: restorePick(); break;
                        default: askPermissions(); openAppSettingsIfDenied();
                    }
                })
                .setNegativeButton("Schließen", null).show();
    }

    private void askKm(Runnable after) {
        LinearLayout f = form();
        double cur = Store.kmPrecise(this);
        EditText e = field(f, "Aktueller Kilometerstand laut Tacho", Double.isNaN(cur) ? "" : String.valueOf(Math.round(cur)));
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        TextView t = text("Danach zählt die App automatisch weiter. Wenn der Tacho mal abweicht, "
                + "hier oder in der letzten Fahrt korrigieren.", 12, C_SUB, false);
        t.setPadding(0, dp(8), 0, 0);
        f.addView(t);
        new AlertDialog.Builder(this)
                .setTitle("Kilometerstand")
                .setView(f)
                .setPositiveButton("Übernehmen", (d, w) -> {
                    try {
                        long km = Long.parseLong(e.getText().toString().trim());
                        Store.setKmPrecise(this, km);
                        updateStatus();
                        if (after != null) after.run();
                    } catch (NumberFormatException ex) {
                        toast("Bitte nur Zahlen eingeben.");
                    }
                })
                .setNegativeButton("Abbrechen", null).show();
    }

    private void placeDialog(String key, String name) {
        LinearLayout f = form();
        EditText e = field(f, "Adresse", Store.placeAddr(this, key));
        TextView t = text("Adresse eintippen und speichern – oder „Aktueller Standort“, wenn du gerade dort bist. "
                + "Fahrten von/nach hier werden automatisch erkannt (Umkreis 300 m).", 12, C_SUB, false);
        t.setPadding(0, dp(8), 0, 0);
        f.addView(t);
        new AlertDialog.Builder(this)
                .setTitle(name)
                .setView(f)
                .setPositiveButton("Adresse speichern", (d, w) -> {
                    String addr = e.getText().toString().trim();
                    if (addr.isEmpty()) {
                        Store.setPlace(this, key, Double.NaN, Double.NaN, "");
                        toast(name + " entfernt");
                        return;
                    }
                    toast("Adresse wird gesucht …");
                    new Thread(() -> {
                        double[] g = Geo.forward(getApplicationContext(), addr);
                        runOnUiThread(() -> {
                            if (g == null) {
                                toast("Adresse nicht gefunden – bitte mit PLZ und Ort eingeben.");
                            } else {
                                Store.setPlace(this, key, g[0], g[1], addr);
                                toast(name + " gespeichert");
                            }
                        });
                    }).start();
                })
                .setNeutralButton("Aktueller Standort", (d, w) -> currentLocation(loc -> {
                    if (loc == null) {
                        toast("Standort nicht gefunden – bitte draußen nochmal versuchen oder Adresse eintippen.");
                        return;
                    }
                    new Thread(() -> {
                        String addr = Geo.reverse(getApplicationContext(), loc.getLatitude(), loc.getLongitude());
                        String a = addr != null ? addr : TripFinisher.coords(loc.getLatitude(), loc.getLongitude());
                        Store.setPlace(this, key, loc.getLatitude(), loc.getLongitude(), a);
                        runOnUiThread(() -> toast(name + " gespeichert: " + a));
                    }).start();
                }))
                .setNegativeButton("Abbrechen", null).show();
    }

    @SuppressWarnings({"deprecation", "MissingPermission"})
    private void currentLocation(Consumer<Location> cb) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            askPermissions();
            return;
        }
        LocationManager lm = getSystemService(LocationManager.class);
        if (lm == null) {
            cb.accept(null);
            return;
        }
        String prov = LocationManager.GPS_PROVIDER;
        if (Build.VERSION.SDK_INT >= 31 && lm.hasProvider(LocationManager.FUSED_PROVIDER)) prov = LocationManager.FUSED_PROVIDER;
        else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) prov = LocationManager.NETWORK_PROVIDER;
        toast("Standort wird ermittelt …");
        final Location fallback = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(prov, null, getMainExecutor(), loc -> cb.accept(loc != null ? loc : fallback));
            } else {
                lm.requestSingleUpdate(prov, new LocationListener() {
                    @Override public void onLocationChanged(Location loc) { cb.accept(loc); }
                    @Override public void onProviderEnabled(String p) { }
                    @Override public void onProviderDisabled(String p) { cb.accept(fallback); }
                    @Override public void onStatusChanged(String p, int s, Bundle b) { }
                }, Looper.getMainLooper());
            }
        } catch (Exception e) {
            cb.accept(fallback);
        }
    }

    private void calendarDialog() {
        if (!CalendarHelper.allowed(this)) {
            toast("Bitte zuerst den Kalender erlauben.");
            askPermissions();
            return;
        }
        List<String[]> cals = CalendarHelper.calendars(this);
        if (cals.isEmpty()) {
            toast("Keine Kalender auf dem Handy gefunden.");
            return;
        }
        Set<String> sel = Store.calendars(this);
        String[] names = new String[cals.size()];
        boolean[] checked = new boolean[cals.size()];
        for (int i = 0; i < cals.size(); i++) {
            String[] c = cals.get(i);
            names[i] = c[1] + (c[2].isEmpty() || c[2].equals(c[1]) ? "" : "  (" + c[2] + ")");
            checked[i] = sel.isEmpty() || sel.contains(c[0]);
        }
        new AlertDialog.Builder(this)
                .setTitle("Welche Kalender lesen?")
                .setMultiChoiceItems(names, checked, (d, w, on) -> checked[w] = on)
                .setPositiveButton("Speichern", (d, w) -> {
                    Set<String> ns = new HashSet<>();
                    for (int i = 0; i < cals.size(); i++) if (checked[i]) ns.add(cals.get(i)[0]);
                    if (ns.isEmpty()) toast("Nichts gewählt – es werden alle Kalender gelesen.");
                    if (ns.size() == cals.size()) ns.clear();
                    Store.setCalendars(this, ns);
                    lastHint = 0;
                    updateHint();
                })
                .setNegativeButton("Abbrechen", null).show();
    }

    private void vehicleDialog() {
        LinearLayout f = form();
        EditText k = field(f, "Kennzeichen", Store.kennzeichen(this));
        EditText fa = field(f, "Fahrer", Store.fahrer(this));
        new AlertDialog.Builder(this)
                .setTitle("Fahrzeug & Fahrer")
                .setView(f)
                .setPositiveButton("Speichern", (d, w) -> {
                    Store.p(this).edit().putString("kennzeichen", k.getText().toString().trim())
                            .putString("fahrer", fa.getText().toString().trim()).apply();
                    subTitle.setText(vehicleLine());
                })
                .setNegativeButton("Abbrechen", null).show();
    }

    private void batterySettings() {
        toast("Unter „Akku“ → „Nicht eingeschränkt“ wählen.");
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", getPackageName(), null)));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception ignored) { }
        }
    }

    private void openAppSettingsIfDenied() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                || !CalendarHelper.allowed(this)) {
            toast("Falls nichts erscheint: in den App-Einstellungen Standort und Kalender erlauben.");
        }
    }

    private void backup() {
        try {
            String json = Store.backupJson(this);
            String name = "Fahrtenbuch_Backup_" + new SimpleDateFormat("yyyyMMdd_HHmm", DE).format(new Date()) + ".json";
            Uri u = Export.writeDownload(this, name, "application/json", json.getBytes(StandardCharsets.UTF_8));
            toast("Backup in Download/Fahrtenbuch gespeichert");
            share(u, "application/json", name);
        } catch (Exception e) {
            toast("Backup fehlgeschlagen: " + e.getMessage());
        }
    }

    @SuppressWarnings("deprecation")
    private void restorePick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_RESTORE);
        } catch (Exception e) {
            toast("Dateiauswahl nicht verfügbar.");
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_RESTORE || res != RESULT_OK || data == null || data.getData() == null) return;
        final String json;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            if (in == null) throw new Exception("Datei leer");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            json = bo.toString("UTF-8");
        } catch (Exception e) {
            toast("Datei konnte nicht gelesen werden.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Backup laden?")
                .setMessage("Alle Fahrten auf dem Handy werden durch das Backup ersetzt.")
                .setPositiveButton("Laden", (d, w) -> {
                    try {
                        int n = Store.restoreJson(this, json);
                        toast(n + " Fahrten geladen");
                        refreshList();
                        updateStatus();
                    } catch (Exception e) {
                        toast("Das ist kein gültiges Fahrtenbuch-Backup.");
                    }
                })
                .setNegativeButton("Abbrechen", null).show();
    }

    // ======================= Berechtigungen & Willkommen =======================

    private void askPermissions() {
        List<String> need = new ArrayList<>();
        need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        need.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        need.add(Manifest.permission.READ_CALENDAR);
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS);
        List<String> missing = new ArrayList<>();
        for (String p : need) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        lastHint = 0;
        updateHint();
    }

    private void welcome() {
        new AlertDialog.Builder(this)
                .setTitle("Willkommen im Fahrtenbuch")
                .setMessage("So funktioniert's:\n\n"
                        + "1. Beim Losfahren START drücken, beim Ankommen STOPP (geht auch direkt in der Benachrichtigung).\n"
                        + "2. Die km zählt das GPS. Ziel, Zweck und Geschäftspartner holt die App aus deinem Kalender-Termin.\n"
                        + "3. Ohne passenden Termin wird die GPS-Adresse eingetragen und die Fahrt gelb markiert – kurz antippen und Fahrtart wählen.\n\n"
                        + "Einmalig einrichten: Kilometerstand, Zuhause (und ggf. Büro) unter Einstellungen.")
                .setPositiveButton("Kilometerstand eingeben", (d, w) -> {
                    Store.p(this).edit().putBoolean("welcomed", true).apply();
                    askKm(() -> placeDialog("home", "Zuhause"));
                })
                .setNegativeButton("Später", (d, w) -> Store.p(this).edit().putBoolean("welcomed", true).apply())
                .show();
    }

    // ======================= Helfer =======================

    private String vehicleLine() {
        String k = Store.kennzeichen(this), f = Store.fahrer(this);
        if (k.isEmpty() && f.isEmpty()) return "Görner Immobilien";
        return (k.isEmpty() ? "" : k) + (k.isEmpty() || f.isEmpty() ? "" : " · ") + f;
    }

    private Date monthStart(int y, int m) {
        Calendar c = Calendar.getInstance();
        c.set(y, m, 1, 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTime();
    }

    private String hm(long t) {
        return new SimpleDateFormat("HH:mm", DE).format(new Date(t));
    }

    private String nowStamp() {
        return new SimpleDateFormat("dd.MM.yyyy HH:mm", DE).format(new Date());
    }

    private String num(long n) {
        return NumberFormat.getIntegerInstance(DE).format(n);
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button smallBtn(String s, int color) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextColor(C_WHITE);
        b.setTextSize(15);
        b.setBackground(round(color, 12));
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private LinearLayout form() {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(8), dp(20), dp(8));
        return f;
    }

    private ScrollView scroll(View v) {
        ScrollView s = new ScrollView(this);
        s.addView(v);
        return s;
    }

    private TextView label(String s) {
        TextView t = text(s, 12, C_SUB, true);
        t.setPadding(0, dp(10), 0, 0);
        return t;
    }

    private EditText field(LinearLayout f, String lbl, String value) {
        f.addView(label(lbl));
        EditText e = new EditText(this);
        e.setText(value == null ? "" : value);
        e.setTextSize(15);
        e.setTextColor(C_TEXT);
        e.setBackgroundColor(Color.TRANSPARENT);
        e.setPadding(0, dp(6), 0, dp(6));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        f.addView(e);
        View line = new View(this);
        line.setBackgroundColor(0xFFCCD3DC);
        f.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        return e;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
