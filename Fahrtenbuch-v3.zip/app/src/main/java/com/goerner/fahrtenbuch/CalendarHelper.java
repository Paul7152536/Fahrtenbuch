package com.goerner.fahrtenbuch;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Attendees;
import android.provider.CalendarContract.Calendars;
import android.provider.CalendarContract.Instances;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Liest Termine aus dem Handy-Kalender (Google, Samsung, Outlook – alles, was auf dem Handy synchronisiert ist). */
public class CalendarHelper {

    static boolean allowed(Context c) {
        return c.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED;
    }

    /** Alle Termine (aus den gewählten Kalendern) im Zeitraum. */
    static List<Matcher.Ev> events(Context c, long from, long to) {
        List<Matcher.Ev> out = new ArrayList<>();
        if (!allowed(c)) return out;
        Set<String> sel = Store.calendars(c);
        Uri.Builder b = Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(b, from);
        ContentUris.appendId(b, to);
        String[] proj = {Instances.EVENT_ID, Instances.TITLE, Instances.EVENT_LOCATION,
                Instances.BEGIN, Instances.END, Instances.ALL_DAY, Instances.CALENDAR_ID};
        try (Cursor cur = c.getContentResolver().query(b.build(), proj, null, null, Instances.BEGIN + " ASC")) {
            while (cur != null && cur.moveToNext()) {
                String calId = String.valueOf(cur.getLong(6));
                if (!sel.isEmpty() && !sel.contains(calId)) continue;
                out.add(new Matcher.Ev(cur.getLong(0), cur.getLong(3), cur.getLong(4),
                        cur.getString(1), cur.getString(2), cur.getInt(5) == 1));
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** Teilnehmer eines Termins (ohne Organisator) als Geschäftspartner, max. 3. */
    static String partner(Context c, long eventId) {
        if (!allowed(c)) return "";
        String[] proj = {Attendees.ATTENDEE_NAME, Attendees.ATTENDEE_EMAIL, Attendees.ATTENDEE_RELATIONSHIP};
        StringBuilder sb = new StringBuilder();
        int n = 0;
        try (Cursor cur = c.getContentResolver().query(Attendees.CONTENT_URI, proj,
                Attendees.EVENT_ID + "=?", new String[]{String.valueOf(eventId)}, null)) {
            while (cur != null && cur.moveToNext() && n < 3) {
                if (cur.getInt(2) == Attendees.RELATIONSHIP_ORGANIZER) continue;
                String name = cur.getString(0);
                if (name == null || name.trim().isEmpty()) name = cur.getString(1);
                if (name == null || name.trim().isEmpty()) continue;
                if (sb.length() > 0) sb.append(", ");
                sb.append(name.trim());
                n++;
            }
        } catch (Exception ignored) { }
        return sb.toString();
    }

    /** Liste der Kalender auf dem Handy: {id, Name, Konto}. */
    static List<String[]> calendars(Context c) {
        List<String[]> out = new ArrayList<>();
        if (!allowed(c)) return out;
        String[] proj = {Calendars._ID, Calendars.CALENDAR_DISPLAY_NAME, Calendars.ACCOUNT_NAME};
        try (Cursor cur = c.getContentResolver().query(Calendars.CONTENT_URI, proj, null, null, null)) {
            while (cur != null && cur.moveToNext()) {
                out.add(new String[]{String.valueOf(cur.getLong(0)),
                        nz(cur.getString(1)), nz(cur.getString(2))});
            }
        } catch (Exception ignored) { }
        return out;
    }

    static String nz(String s) { return s == null ? "" : s; }

    @SuppressWarnings("unused")
    static Uri eventUri(long id) {
        return ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id);
    }
}
