package com.goerner.fahrtenbuch;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Baut das Fahrtenbuch als Excel-Datei für den Steuerberater:
 * Übersicht · ein Blatt pro Monat · Nachweise (Kalender/GPS) · Änderungsprotokoll.
 */
public class FahrtenbuchExcel {
    static final String[] MONATE = {"Januar", "Februar", "März", "April", "Mai", "Juni", "Juli",
            "August", "September", "Oktober", "November", "Dezember"};
    static final String[] MON_KURZ = {"Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"};
    static final String STORNO = "storniert";

    public static byte[] build(List<Trip> input, String titel, String kennzeichen, String fahrer,
                               String firma, long now) throws Exception {
        List<Trip> trips = new ArrayList<>(input);
        trips.sort(Comparator.comparingLong(t -> t.start));
        String kopf = firma + (kennzeichen.isEmpty() ? "" : " · Kennzeichen: " + kennzeichen)
                + (fahrer.isEmpty() ? "" : " · Fahrer: " + fahrer);

        // nach Monaten gruppieren (Schlüssel = Jahr*100+Monat)
        Map<Integer, List<Trip>> byMonth = new LinkedHashMap<>();
        for (Trip t : trips) {
            LocalDateTime d = ldt(t.start);
            byMonth.computeIfAbsent(d.getYear() * 100 + d.getMonthValue(), k -> new ArrayList<>()).add(t);
        }

        Xlsx x = new Xlsx();
        x.creator(fahrer.isEmpty() ? firma : fahrer);
        Xlsx.Sheet ov = x.sheet("Übersicht");

        // ---------- Monatsblätter ----------
        List<Object[]> monthRows = new ArrayList<>(); // {name, sheetName, sumRow, fahrten, km, g, p, wa, open}
        for (Map.Entry<Integer, List<Trip>> e : byMonth.entrySet()) {
            int y = e.getKey() / 100, m = e.getKey() % 100;
            String sheetName = MON_KURZ[m - 1] + " " + y;
            String longName = MONATE[m - 1] + " " + y;
            Xlsx.Sheet s = x.sheet(sheetName);
            long[] tot = monthSheet(s, e.getValue(), "Fahrtenbuch " + longName, kopf);
            monthRows.add(new Object[]{longName, sheetName, (int) tot[0], tot[1], tot[2], tot[3], tot[4], tot[5], tot[6]});
        }

        // ---------- Übersicht ----------
        ov.widths = new double[]{20, 10, 14, 15, 12, 17, 15, 15};
        ov.str(1, 1, "Fahrtenbuch " + titel, Xlsx.TITLE);
        ov.height(1, 22);
        ov.str(2, 1, kopf, Xlsx.SUB);
        Trip first = firstValid(trips), last = lastValid(trips);
        if (first != null && last != null) {
            ov.str(3, 1, "Zeitraum: " + date(first.start) + " – " + date(last.end)
                    + "   ·   Kilometerstand: " + String.format(java.util.Locale.GERMANY, "%,d", first.kmStart)
                    + " → " + String.format(java.util.Locale.GERMANY, "%,d", last.kmEnd), Xlsx.SUB);
        }
        String[] h = {"Monat", "Fahrten", "Gefahrene km", "km geschäftlich", "km privat",
                "km Wohnung–Arbeit", "km noch offen", "Anteil geschäftlich"};
        int hr = 5;
        for (int i = 0; i < h.length; i++) ov.str(hr, i + 1, h[i], Xlsx.HEAD);
        ov.height(hr, 30);
        int r = hr + 1;
        long sF = 0, sK = 0, sG = 0, sP = 0, sW = 0, sO = 0;
        for (Object[] mr : monthRows) {
            String sh = Xlsx.q((String) mr[1]);
            int sum = (Integer) mr[2];
            long f = (Long) mr[3], km = (Long) mr[4], g = (Long) mr[5], p = (Long) mr[6], w = (Long) mr[7], o = (Long) mr[8];
            int v = o > 0 ? Xlsx.YELLOW : Xlsx.NORMAL;
            ov.str(r, 1, (String) mr[0], Xlsx.data(v, Xlsx.TEXT));
            ov.num(r, 2, f, Xlsx.data(v, Xlsx.INT));
            ov.formula(r, 3, sh + "!G" + sum, km, Xlsx.data(v, Xlsx.INT));
            ov.formula(r, 4, sh + "!M" + sum, g, Xlsx.data(v, Xlsx.INT));
            ov.formula(r, 5, sh + "!N" + sum, p, Xlsx.data(v, Xlsx.INT));
            ov.formula(r, 6, sh + "!O" + sum, w, Xlsx.data(v, Xlsx.INT));
            ov.num(r, 7, o, Xlsx.data(v, Xlsx.INT));
            ov.formula(r, 8, "IF(C" + r + "=0,0,D" + r + "/C" + r + ")", km == 0 ? 0 : (double) g / km, Xlsx.data(v, Xlsx.PCT));
            sF += f; sK += km; sG += g; sP += p; sW += w; sO += o;
            r++;
        }
        int a = hr + 1, b = r - 1;
        ov.str(r, 1, "Summe", Xlsx.SUM_LABEL);
        long[] sums = {sF, sK, sG, sP, sW, sO};
        for (int c = 2; c <= 7; c++) {
            String col = Xlsx.col(c);
            ov.formula(r, c, "SUM(" + col + a + ":" + col + b + ")", sums[c - 2], Xlsx.SUM_INT);
        }
        ov.formula(r, 8, "IF(C" + r + "=0,0,D" + r + "/C" + r + ")", sK == 0 ? 0 : (double) sG / sK, Xlsx.SUM_PCT);
        r += 2;
        if (sO > 0) {
            ov.str(r++, 1, "Achtung: " + sO + " km sind noch keiner Fahrtart zugeordnet (gelb markiert) – bitte in der App nachtragen.", Xlsx.BOLD);
        }
        ov.str(r++, 1, "Elektronisch erfasst: Kilometer per GPS, Reiseziel/-zweck/Geschäftspartner aus dem Kalender.", Xlsx.NOTE);
        ov.str(r++, 1, "Nachträgliche Änderungen sind mit Zeitpunkt im Blatt „Änderungsprotokoll“ dokumentiert; Stornos bleiben sichtbar.", Xlsx.NOTE);
        ov.str(r, 1, "Erstellt am " + date(now) + " um " + time(now) + " Uhr.", Xlsx.NOTE);
        ov.landscape = false;
        ov.footerLeft = "Fahrtenbuch " + titel;

        // ---------- Nachweise ----------
        Xlsx.Sheet nw = x.sheet("Nachweise");
        nw.widths = new double[]{6, 11, 8, 34, 13, 38, 9, 10, 10};
        nw.str(1, 1, "Nachweise je Fahrt", Xlsx.TITLE);
        nw.str(2, 1, "Kalendertermin, tatsächliche Position am Ziel laut GPS und GPS-Strecke im Vergleich zum Kilometerstand.", Xlsx.SUB);
        String[] nh = {"Nr", "Datum", "Abfahrt", "Kalendertermin", "Ziel erkannt über", "Position laut GPS am Ziel",
                "GPS-km", "Tacho-km", "Differenz"};
        for (int i = 0; i < nh.length; i++) nw.str(4, i + 1, nh[i], Xlsx.HEAD);
        nw.height(4, 30);
        r = 5;
        for (Trip t : trips) {
            int v = t.storniert ? Xlsx.STORNO : Xlsx.NORMAL;
            nw.num(r, 1, t.nr, Xlsx.data(v, Xlsx.INT));
            nw.num(r, 2, dateSerial(t.start), Xlsx.data(v, Xlsx.DATE));
            nw.num(r, 3, timeSerial(t.start), Xlsx.data(v, Xlsx.TIME));
            nw.str(r, 4, t.termin.isEmpty() ? "–" : t.termin, Xlsx.data(v, Xlsx.TEXT));
            nw.str(r, 5, t.quelle, Xlsx.data(v, Xlsx.TEXT));
            nw.str(r, 6, t.zielGps, Xlsx.data(v, Xlsx.TEXT));
            nw.num(r, 7, t.gpsKm, Xlsx.data(v, Xlsx.DEC));
            nw.num(r, 8, t.km(), Xlsx.data(v, Xlsx.INT));
            nw.formula(r, 9, "H" + r + "-G" + r, t.km() - t.gpsKm, Xlsx.data(v, Xlsx.DEC));
            r++;
        }
        nw.freezeRows = 4;
        nw.printTitleRows = "$4:$4";
        nw.footerLeft = "Fahrtenbuch " + titel;

        // ---------- Änderungsprotokoll ----------
        Xlsx.Sheet lg = x.sheet("Änderungsprotokoll");
        lg.widths = new double[]{6, 11, 17, 90};
        lg.str(1, 1, "Änderungsprotokoll", Xlsx.TITLE);
        lg.str(2, 1, "Jede automatische Erfassung und jede spätere Änderung mit Zeitpunkt (alt → neu).", Xlsx.SUB);
        String[] lh = {"Nr", "Fahrt vom", "Zeitpunkt", "Eintrag"};
        for (int i = 0; i < lh.length; i++) lg.str(4, i + 1, lh[i], Xlsx.HEAD);
        r = 5;
        for (Trip t : trips) {
            for (String entry : t.log) {
                String when = "", what = entry;
                int idx = entry.indexOf(": ");
                if (idx > 0 && idx <= 17) {
                    when = entry.substring(0, idx);
                    what = entry.substring(idx + 2);
                }
                lg.num(r, 1, t.nr, Xlsx.data(Xlsx.NORMAL, Xlsx.INT));
                lg.num(r, 2, dateSerial(t.start), Xlsx.data(Xlsx.NORMAL, Xlsx.DATE));
                lg.str(r, 3, when, Xlsx.data(Xlsx.NORMAL, Xlsx.TEXT));
                lg.str(r, 4, what, Xlsx.data(Xlsx.NORMAL, Xlsx.TEXT));
                r++;
            }
        }
        lg.freezeRows = 4;
        lg.printTitleRows = "$4:$4";
        lg.landscape = false;
        lg.footerLeft = "Fahrtenbuch " + titel;

        return x.build();
    }

    /** Schreibt ein Monatsblatt. Rückgabe: {Summenzeile, Fahrten, km, geschäftlich, privat, Wohnung–Arbeit, offen}. */
    static long[] monthSheet(Xlsx.Sheet s, List<Trip> trips, String titel, String kopf) {
        s.widths = new double[]{5, 11, 8, 8, 11, 11, 10.5, 30, 32, 30, 20, 14, 11, 9, 12, 22};
        s.str(1, 1, titel, Xlsx.TITLE);
        s.height(1, 22);
        s.str(2, 1, kopf, Xlsx.SUB);
        String[] h = {"Nr", "Datum", "Abfahrt", "Ankunft", "Km-Stand Beginn", "Km-Stand Ende", "Gefahrene km",
                "Startort", "Reiseziel", "Reisezweck", "Geschäftspartner", "Fahrtart",
                "km geschäftlich", "km privat", "km Wohnung–Arbeit", "Bemerkung"};
        int hr = 4;
        for (int i = 0; i < h.length; i++) s.str(hr, i + 1, h[i], Xlsx.HEAD);
        s.height(hr, 40);
        int r = hr + 1;
        long n = 0, km = 0, g = 0, p = 0, w = 0, o = 0;
        for (Trip t : trips) {
            boolean st = t.storniert;
            boolean open = !st && Trip.PRUEFEN.equals(t.art);
            int v = st ? Xlsx.STORNO : open ? Xlsx.YELLOW : Xlsx.NORMAL;
            long k = t.km();
            s.num(r, 1, t.nr, Xlsx.data(v, Xlsx.INT));
            s.num(r, 2, dateSerial(t.start), Xlsx.data(v, Xlsx.DATE));
            s.num(r, 3, timeSerial(t.start), Xlsx.data(v, Xlsx.TIME));
            s.num(r, 4, timeSerial(t.end), Xlsx.data(v, Xlsx.TIME));
            s.num(r, 5, t.kmStart, Xlsx.data(v, Xlsx.INT));
            s.num(r, 6, t.kmEnd, Xlsx.data(v, Xlsx.INT));
            s.formula(r, 7, "F" + r + "-E" + r, k, Xlsx.data(v, Xlsx.INT));
            s.str(r, 8, t.startOrt, Xlsx.data(v, Xlsx.TEXT));
            s.str(r, 9, t.ziel, Xlsx.data(v, Xlsx.TEXT));
            s.str(r, 10, t.zweck, Xlsx.data(v, Xlsx.TEXT));
            s.str(r, 11, t.partner, Xlsx.data(v, Xlsx.TEXT));
            s.str(r, 12, st ? STORNO : t.art, Xlsx.data(v, Xlsx.TEXT));
            int colKm = 0;
            if (!st) {
                n++;
                km += k;
                if (Trip.GESCHAEFTLICH.equals(t.art)) { g += k; colKm = 13; }
                else if (Trip.PRIVAT.equals(t.art)) { p += k; colKm = 14; }
                else if (Trip.WOHNUNG_ARBEIT.equals(t.art)) { w += k; colKm = 15; }
                else o += k;
            }
            for (int c = 13; c <= 15; c++) {
                if (c == colKm) s.formula(r, c, "G" + r, k, Xlsx.data(v, Xlsx.INT));
                else s.blank(r, c, Xlsx.data(v, Xlsx.INT));
            }
            String bem;
            if (st) bem = "storniert – nicht mitgezählt";
            else if (open) bem = "Fahrtart noch offen";
            else if (t.log.size() > 1) bem = "geändert, s. Änderungsprotokoll";
            else bem = "";
            s.str(r, 16, bem, Xlsx.data(v, Xlsx.TEXT));
            r++;
        }
        int a = hr + 1, b = r - 1;
        for (int c = 1; c <= 16; c++) s.blank(r, c, Xlsx.SUM_LABEL);
        s.str(r, 2, "Summe", Xlsx.SUM_LABEL);
        s.formula(r, 7, "SUMIF(L" + a + ":L" + b + ",\"<>" + STORNO + "\",G" + a + ":G" + b + ")", km, Xlsx.SUM_INT);
        s.formula(r, 13, "SUM(M" + a + ":M" + b + ")", g, Xlsx.SUM_INT);
        s.formula(r, 14, "SUM(N" + a + ":N" + b + ")", p, Xlsx.SUM_INT);
        s.formula(r, 15, "SUM(O" + a + ":O" + b + ")", w, Xlsx.SUM_INT);
        int sumRow = r;
        if (o > 0) s.str(r + 2, 1, "Gelb = Fahrtart noch offen (" + o + " km). Bitte in der App zuordnen.", Xlsx.NOTE);
        s.freezeRows = hr;
        s.autoFilter = "A" + hr + ":P" + b;
        s.printTitleRows = "$" + hr + ":$" + hr;
        s.footerLeft = titel;
        return new long[]{sumRow, n, km, g, p, w, o};
    }

    // ---------- Hilfen ----------

    static Trip firstValid(List<Trip> l) {
        for (Trip t : l) if (!t.storniert) return t;
        return null;
    }

    static Trip lastValid(List<Trip> l) {
        for (int i = l.size() - 1; i >= 0; i--) if (!l.get(i).storniert) return l.get(i);
        return null;
    }

    static LocalDateTime ldt(long ms) {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), ZoneId.systemDefault());
    }

    /** Excel-Datum (Tage seit 30.12.1899). */
    static double dateSerial(long ms) {
        return ChronoUnit.DAYS.between(LocalDate.of(1899, 12, 30), ldt(ms).toLocalDate());
    }

    /** Excel-Uhrzeit (Bruchteil eines Tages, auf Minuten gerundet). */
    static double timeSerial(long ms) {
        LocalDateTime d = ldt(ms);
        return ((d.getHour() * 60 + d.getMinute()) * 60 + 1) / 86400.0; // +1 s gegen Rundung nach unten
    }

    static String date(long ms) {
        LocalDateTime d = ldt(ms);
        return String.format("%02d.%02d.%04d", d.getDayOfMonth(), d.getMonthValue(), d.getYear());
    }

    static String time(long ms) {
        LocalDateTime d = ldt(ms);
        return String.format("%02d:%02d", d.getHour(), d.getMinute());
    }
}
