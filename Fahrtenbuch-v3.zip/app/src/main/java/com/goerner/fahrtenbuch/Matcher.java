package com.goerner.fahrtenbuch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Reine Zuordnungslogik (ohne Android), damit sie testbar ist:
 * Welcher Kalendertermin ist das Ziel einer Fahrt?
 */
public class Matcher {
    static final long MIN = 60_000L;

    /** Termin-Daten, wie sie aus dem Kalender kommen. */
    public static class Ev {
        public long id, begin, end;
        public String title = "", location = "";
        public boolean allDay;

        public Ev() { }

        public Ev(long id, long begin, long end, String title, String location, boolean allDay) {
            this.id = id;
            this.begin = begin;
            this.end = end;
            this.title = title == null ? "" : title;
            this.location = location == null ? "" : location;
            this.allDay = allDay;
        }
    }

    /**
     * Punktzahl fuer "dieser Termin ist das Ziel" (kleiner = besser), -1 = passt nicht.
     * Regeln:
     *  - Ganztägige Termine zählen nicht.
     *  - Termin darf nicht schon vor der Abfahrt vorbei gewesen sein.
     *  - Terminbeginn zwischen 45 Min vor und 150 Min nach der Ankunft.
     *  - Zu früh ankommen ist normal (zählt einfach), zu spät ankommen zählt doppelt.
     *  - Termine ohne Ort bekommen 30 Min Malus.
     */
    public static long score(Ev e, long tripStart, long tripEnd) {
        if (e.allDay) return -1;
        if (e.end <= tripStart) return -1;
        long d = e.begin - tripEnd;
        if (d < -45 * MIN || d > 150 * MIN) return -1;
        long s = d >= 0 ? d : -d * 2;
        if (e.location == null || e.location.trim().isEmpty()) s += 30 * MIN;
        return s;
    }

    /** Kandidaten, bester zuerst. */
    public static List<Ev> rank(List<Ev> evs, long tripStart, long tripEnd) {
        List<long[]> scored = new ArrayList<>();
        for (int i = 0; i < evs.size(); i++) {
            long s = score(evs.get(i), tripStart, tripEnd);
            if (s >= 0) scored.add(new long[]{s, i});
        }
        Collections.sort(scored, (a, b) -> Long.compare(a[0], b[0]));
        List<Ev> out = new ArrayList<>();
        for (long[] x : scored) out.add(evs.get((int) x[1]));
        return out;
    }

    /** Kilometerstände: Beginn, Ende (ganze km) aus genauem Stand + GPS-Strecke. */
    public static long[] odometer(double precise, double meters) {
        double after = precise + meters / 1000.0;
        return new long[]{Math.round(precise), Math.round(after)};
    }
}
