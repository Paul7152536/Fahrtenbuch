package com.goerner.fahrtenbuch;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Export als CSV (öffnet sich direkt in Excel) und Backup – landet im Ordner Download/Fahrtenbuch. */
public class Export {

    static Uri writeDownload(Context c, String name, String mime, byte[] data) throws IOException {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Fahrtenbuch");
        Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IOException("Datei konnte nicht angelegt werden");
        try (OutputStream os = c.getContentResolver().openOutputStream(uri)) {
            if (os == null) throw new IOException("Datei konnte nicht geschrieben werden");
            os.write(data);
        }
        return uri;
    }

    static String csv(Context c, List<Trip> trips, String titel) {
        SimpleDateFormat d = new SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY);
        SimpleDateFormat h = new SimpleDateFormat("HH:mm", Locale.GERMANY);
        StringBuilder sb = new StringBuilder("﻿");
        row(sb, "Fahrtenbuch " + titel, "Kennzeichen: " + Store.kennzeichen(c), "Fahrer: " + Store.fahrer(c));
        row(sb);
        row(sb, "Nr", "Datum", "Abfahrt", "Ankunft", "Km-Stand Beginn", "Km-Stand Ende", "Gefahrene km",
                "Startort", "Reiseziel", "Reisezweck", "Geschäftspartner", "Fahrtart",
                "km geschäftlich", "km privat", "km Wohnung–Arbeit", "Kalendertermin",
                "Position laut GPS (Ziel)", "GPS-km", "Status", "Änderungen");
        long sum = 0, g = 0, pr = 0, wa = 0, open = 0;
        for (Trip t : trips) {
            long km = t.km();
            boolean st = t.storniert;
            String kg = "", kp = "", kw = "";
            if (!st) {
                sum += km;
                switch (t.art) {
                    case Trip.GESCHAEFTLICH: g += km; kg = String.valueOf(km); break;
                    case Trip.PRIVAT: pr += km; kp = String.valueOf(km); break;
                    case Trip.WOHNUNG_ARBEIT: wa += km; kw = String.valueOf(km); break;
                    default: open += km;
                }
            }
            row(sb, String.valueOf(t.nr), d.format(new Date(t.start)), h.format(new Date(t.start)),
                    h.format(new Date(t.end)), String.valueOf(t.kmStart), String.valueOf(t.kmEnd),
                    String.valueOf(km), t.startOrt, t.ziel, t.zweck, t.partner, t.art, kg, kp, kw,
                    t.termin, t.zielGps, String.format(Locale.GERMANY, "%.1f", t.gpsKm),
                    st ? "STORNIERT" : "", String.join(" | ", t.log));
        }
        row(sb);
        row(sb, "", "Summe", "", "", "", "", String.valueOf(sum), "", "", "", "", "",
                String.valueOf(g), String.valueOf(pr), String.valueOf(wa));
        if (open > 0) row(sb, "", "Noch zu prüfen (km)", "", "", "", "", String.valueOf(open));
        row(sb, "", "Erstellt am", d.format(new Date()) + " " + h.format(new Date()));
        return sb.toString();
    }

    static Uri exportCsv(Context c, List<Trip> trips, String titel) throws IOException {
        String name = "Fahrtenbuch_" + titel.replace(' ', '_') + "_"
                + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.GERMANY).format(new Date()) + ".csv";
        return writeDownload(c, name, "text/csv", csv(c, trips, titel).getBytes(StandardCharsets.UTF_8));
    }

    /** Echte Excel-Datei für den Steuerberater (Übersicht, Monatsblätter, Nachweise, Änderungsprotokoll). */
    static Uri exportXlsx(Context c, List<Trip> trips, String titel) throws Exception {
        String name = "Fahrtenbuch_" + titel.replace(' ', '_') + "_"
                + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.GERMANY).format(new Date()) + ".xlsx";
        byte[] data = FahrtenbuchExcel.build(trips, titel, Store.kennzeichen(c), Store.fahrer(c),
                "Görner Immobilien", System.currentTimeMillis());
        return writeDownload(c, name, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", data);
    }

    private static void row(StringBuilder sb, String... cells) {
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) sb.append(';');
            String s = cells[i] == null ? "" : cells[i];
            if (s.contains(";") || s.contains("\"") || s.contains("\n")) {
                s = "\"" + s.replace("\"", "\"\"") + "\"";
            }
            sb.append(s);
        }
        sb.append("\r\n");
    }
}
