package com.goerner.fahrtenbuch;

import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Macht aus Start/Stopp + GPS + Kalender einen fertigen Fahrtenbuch-Eintrag. */
public class TripFinisher {
    static final long MIN = 60_000L;

    /** Läuft im Hintergrund-Thread (Geocoder braucht Netz). */
    static Trip finish(Context c, long startMs, long endMs, double sLat, double sLon,
                       double eLat, double eLon, double distM) throws Exception {
        Trip t = new Trip();
        t.id = startMs;
        t.start = startMs;
        t.end = endMs;
        t.startLat = sLat;
        t.startLon = sLon;
        t.endLat = eLat;
        t.endLon = eLon;
        t.gpsKm = Math.round(distM / 100.0) / 10.0;
        t.created = System.currentTimeMillis();

        // Kilometerstand fortschreiben
        double prec = Store.kmPrecise(c);
        if (Double.isNaN(prec)) prec = 0;
        long[] odo = Matcher.odometer(prec, distM);
        t.kmStart = odo[0];
        t.kmEnd = odo[1];
        Store.setKmPrecise(c, prec + distM / 1000.0);

        List<Trip> all = Store.load(c);
        Trip prev = Store.last(all);

        double[] home = Store.place(c, "home");
        double[] office = Store.place(c, "office");
        boolean startHome = Geo.near(home, sLat, sLon, 300);
        boolean startOffice = Geo.near(office, sLat, sLon, 300);
        boolean endHome = Geo.near(home, eLat, eLon, 300);
        boolean endOffice = Geo.near(office, eLat, eLon, 300);

        // ---------- Startort ----------
        String sAddr = Geo.reverse(c, sLat, sLon);
        if (startHome) {
            t.startOrt = label("Zuhause", Store.placeAddr(c, "home"));
        } else if (startOffice) {
            t.startOrt = label("Büro", Store.placeAddr(c, "office"));
        } else if (prev != null && !prev.ziel.isEmpty()
                && Geo.dist(prev.endLat, prev.endLon, sLat, sLon) <= 500) {
            t.startOrt = prev.ziel;
        } else if (sAddr != null) {
            t.startOrt = sAddr;
        } else if (prev != null && !prev.ziel.isEmpty() && Double.isNaN(sLat)) {
            t.startOrt = prev.ziel;
        } else {
            t.startOrt = Double.isNaN(sLat) ? "unbekannt (kein GPS)" : coords(sLat, sLon);
        }

        // ---------- Ziel: zuerst Kalender ----------
        String eAddr = Geo.reverse(c, eLat, eLon);
        t.zielGps = eAddr != null ? eAddr : (Double.isNaN(eLat) ? "" : coords(eLat, eLon));

        List<Matcher.Ev> evs = CalendarHelper.events(c, endMs - 180 * MIN, endMs + 180 * MIN);
        List<Matcher.Ev> ranked = Matcher.rank(evs, startMs, endMs);
        Matcher.Ev best = null;
        int checked = 0;
        for (Matcher.Ev e : ranked) {
            // Plausibilitaet: liegt der Terminort weit weg vom tatsaechlichen Ziel? Dann war es nicht das Ziel
            // (z. B. Telefontermin oder Termin woanders).
            if (!e.location.trim().isEmpty() && !Double.isNaN(eLat) && checked < 3) {
                checked++;
                double[] g = Geo.forward(c, e.location);
                if (g != null && Geo.dist(g[0], g[1], eLat, eLon) > 3000) continue;
            }
            best = e;
            break;
        }

        SimpleDateFormat hm = new SimpleDateFormat("HH:mm", Locale.GERMANY);
        if (best != null) {
            String loc = best.location.trim();
            t.ziel = loc.isEmpty() ? (eAddr != null ? eAddr : t.zielGps) : loc;
            t.zweck = best.title.trim();
            t.partner = CalendarHelper.partner(c, best.id);
            t.art = Trip.GESCHAEFTLICH;
            t.termin = best.title.trim() + " (" + hm.format(new Date(best.begin)) + " Uhr)";
            t.quelle = "Kalender";
        } else if (endHome) {
            t.ziel = label("Zuhause", Store.placeAddr(c, "home"));
            t.quelle = "Zuhause";
            if (startOffice) {
                t.art = Trip.WOHNUNG_ARBEIT;
                t.zweck = "Fahrt Büro → Wohnung";
            } else if (prev != null && sameDay(prev.end, startMs) && Trip.GESCHAEFTLICH.equals(prev.art)) {
                t.art = Trip.GESCHAEFTLICH;
                t.zweck = "Rückfahrt von: " + (prev.zweck.isEmpty() ? prev.ziel : prev.zweck);
                t.partner = prev.partner;
            } else {
                t.art = Trip.PRUEFEN;
            }
        } else if (endOffice) {
            t.ziel = label("Büro", Store.placeAddr(c, "office"));
            t.quelle = "Büro";
            if (startHome) {
                t.art = Trip.WOHNUNG_ARBEIT;
                t.zweck = "Fahrt Wohnung → Büro";
            } else {
                t.art = Trip.GESCHAEFTLICH;
                t.zweck = (prev != null && sameDay(prev.end, startMs) && Trip.GESCHAEFTLICH.equals(prev.art))
                        ? "Rückfahrt ins Büro von: " + (prev.zweck.isEmpty() ? prev.ziel : prev.zweck)
                        : "Fahrt ins Büro";
            }
        } else {
            t.ziel = t.zielGps.isEmpty() ? "unbekannt (kein GPS)" : t.zielGps;
            t.art = Trip.PRUEFEN;
            t.quelle = "GPS";
        }

        SimpleDateFormat f = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY);
        boolean bt = Store.p(c).getBoolean("autoStart", false);
        t.log.add(f.format(new Date(t.created)) + ": automatisch erfasst (" + (bt ? "Start per Auto-Bluetooth, " : "") + t.quelle
                + ", GPS " + String.format(Locale.GERMANY, "%.1f", t.gpsKm) + " km)");
        Store.add(c, t);
        return t;
    }

    static String label(String name, String addr) {
        return (addr == null || addr.isEmpty()) ? name : name + " (" + addr + ")";
    }

    static String coords(double lat, double lon) {
        return String.format(Locale.US, "%.5f, %.5f", lat, lon);
    }

    static boolean sameDay(long a, long b) {
        Calendar x = Calendar.getInstance(), y = Calendar.getInstance();
        x.setTimeInMillis(a);
        y.setTimeInMillis(b);
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR)
                && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR);
    }
}
