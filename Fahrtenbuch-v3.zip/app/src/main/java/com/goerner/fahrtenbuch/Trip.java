package com.goerner.fahrtenbuch;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Eine Fahrt im Fahrtenbuch. */
public class Trip {
    public static final String GESCHAEFTLICH = "Geschäftlich";
    public static final String PRIVAT = "Privat";
    public static final String WOHNUNG_ARBEIT = "Wohnung–Arbeit";
    public static final String PRUEFEN = "Prüfen";
    public static final String[] ARTEN = {GESCHAEFTLICH, PRIVAT, WOHNUNG_ARBEIT, PRUEFEN};

    public long id;
    public int nr;
    public long start;
    public long end;
    public long kmStart;
    public long kmEnd;
    public double gpsKm;
    public double startLat = Double.NaN, startLon = Double.NaN;
    public double endLat = Double.NaN, endLon = Double.NaN;
    public String startOrt = "";
    public String ziel = "";
    public String zielGps = "";     // tatsaechliche Adresse laut GPS am Ende
    public String zweck = "";
    public String partner = "";
    public String art = PRUEFEN;
    public String termin = "";      // zugeordneter Kalendertermin
    public String quelle = "";      // Kalender / Zuhause / Büro / GPS
    public boolean storniert = false;
    public long created;
    public List<String> log = new ArrayList<>();

    public long km() {
        return Math.max(0, kmEnd - kmStart);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("nr", nr);
        o.put("start", start);
        o.put("end", end);
        o.put("kmStart", kmStart);
        o.put("kmEnd", kmEnd);
        o.put("gpsKm", gpsKm);
        putD(o, "startLat", startLat);
        putD(o, "startLon", startLon);
        putD(o, "endLat", endLat);
        putD(o, "endLon", endLon);
        o.put("startOrt", startOrt);
        o.put("ziel", ziel);
        o.put("zielGps", zielGps);
        o.put("zweck", zweck);
        o.put("partner", partner);
        o.put("art", art);
        o.put("termin", termin);
        o.put("quelle", quelle);
        o.put("storniert", storniert);
        o.put("created", created);
        JSONArray l = new JSONArray();
        for (String s : log) l.put(s);
        o.put("log", l);
        return o;
    }

    public static Trip fromJson(JSONObject o) {
        Trip t = new Trip();
        t.id = o.optLong("id");
        t.nr = o.optInt("nr");
        t.start = o.optLong("start");
        t.end = o.optLong("end");
        t.kmStart = o.optLong("kmStart");
        t.kmEnd = o.optLong("kmEnd");
        t.gpsKm = o.optDouble("gpsKm", 0);
        t.startLat = o.optDouble("startLat", Double.NaN);
        t.startLon = o.optDouble("startLon", Double.NaN);
        t.endLat = o.optDouble("endLat", Double.NaN);
        t.endLon = o.optDouble("endLon", Double.NaN);
        t.startOrt = o.optString("startOrt", "");
        t.ziel = o.optString("ziel", "");
        t.zielGps = o.optString("zielGps", "");
        t.zweck = o.optString("zweck", "");
        t.partner = o.optString("partner", "");
        t.art = o.optString("art", PRUEFEN);
        t.termin = o.optString("termin", "");
        t.quelle = o.optString("quelle", "");
        t.storniert = o.optBoolean("storniert", false);
        t.created = o.optLong("created");
        JSONArray l = o.optJSONArray("log");
        if (l != null) for (int i = 0; i < l.length(); i++) t.log.add(l.optString(i));
        return t;
    }

    private static void putD(JSONObject o, String k, double v) throws JSONException {
        if (!Double.isNaN(v) && !Double.isInfinite(v)) o.put(k, v);
    }
}
