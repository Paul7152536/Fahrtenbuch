package com.goerner.fahrtenbuch;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Speichert Fahrten (JSON-Datei) und Einstellungen (SharedPreferences) lokal auf dem Handy. */
public class Store {
    static final String PREFS = "fahrtenbuch";
    static final String FILE = "fahrten.json";

    static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ---------- Fahrten ----------

    static synchronized List<Trip> load(Context c) {
        List<Trip> out = new ArrayList<>();
        File f = new File(c.getFilesDir(), FILE);
        if (!f.exists()) return out;
        try {
            String s = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) out.add(Trip.fromJson(a.getJSONObject(i)));
        } catch (Exception e) {
            // Defekte Datei nicht ueberschreiben: Kopie sichern
            try {
                File bad = new File(c.getFilesDir(), "fahrten_defekt_" + System.currentTimeMillis() + ".json");
                Files.copy(f.toPath(), bad.toPath());
            } catch (Exception ignored) { }
        }
        Collections.sort(out, (a, b) -> Long.compare(a.start, b.start));
        return out;
    }

    static synchronized void save(Context c, List<Trip> list) throws IOException {
        try {
            JSONArray a = new JSONArray();
            for (Trip t : list) a.put(t.toJson());
            File tmp = new File(c.getFilesDir(), FILE + ".tmp");
            Files.write(tmp.toPath(), a.toString(1).getBytes(StandardCharsets.UTF_8));
            File f = new File(c.getFilesDir(), FILE);
            if (!tmp.renameTo(f)) {
                Files.write(f.toPath(), a.toString(1).getBytes(StandardCharsets.UTF_8));
                tmp.delete();
            }
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    static synchronized void add(Context c, Trip t) throws IOException {
        List<Trip> list = load(c);
        int maxNr = 0;
        for (Trip x : list) maxNr = Math.max(maxNr, x.nr);
        t.nr = maxNr + 1;
        list.add(t);
        save(c, list);
    }

    static synchronized void update(Context c, Trip t) throws IOException {
        List<Trip> list = load(c);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id == t.id) {
                list.set(i, t);
                save(c, list);
                return;
            }
        }
    }

    static long fileStamp(Context c) {
        File f = new File(c.getFilesDir(), FILE);
        return f.exists() ? f.lastModified() + f.length() : 0;
    }

    /** Letzte nicht stornierte Fahrt (oder null). */
    static Trip last(List<Trip> list) {
        for (int i = list.size() - 1; i >= 0; i--) if (!list.get(i).storniert) return list.get(i);
        return null;
    }

    // ---------- Zahlen in Prefs ----------

    static double getD(SharedPreferences p, String k) {
        if (!p.contains(k)) return Double.NaN;
        return Double.longBitsToDouble(p.getLong(k, 0));
    }

    static void putD(SharedPreferences.Editor e, String k, double v) {
        if (Double.isNaN(v)) e.remove(k);
        else e.putLong(k, Double.doubleToRawLongBits(v));
    }

    // ---------- Kilometerstand ----------

    /** Genauer Kilometerstand (mit Nachkommastellen); NaN = noch nicht eingegeben. */
    static double kmPrecise(Context c) {
        return getD(p(c), "kmPrecise");
    }

    static void setKmPrecise(Context c, double km) {
        SharedPreferences.Editor e = p(c).edit();
        putD(e, "kmPrecise", km);
        e.apply();
    }

    // ---------- Orte (Zuhause / Büro) ----------

    static double[] place(Context c, String key) {
        SharedPreferences p = p(c);
        double lat = getD(p, key + "Lat"), lon = getD(p, key + "Lon");
        if (Double.isNaN(lat) || Double.isNaN(lon)) return null;
        return new double[]{lat, lon};
    }

    static String placeAddr(Context c, String key) {
        return p(c).getString(key + "Addr", "");
    }

    static void setPlace(Context c, String key, double lat, double lon, String addr) {
        SharedPreferences.Editor e = p(c).edit();
        putD(e, key + "Lat", lat);
        putD(e, key + "Lon", lon);
        e.putString(key + "Addr", addr == null ? "" : addr);
        e.apply();
    }

    // ---------- Kalender-Auswahl (leer = alle) ----------

    static Set<String> calendars(Context c) {
        return new HashSet<>(p(c).getStringSet("cals", new HashSet<>()));
    }

    static void setCalendars(Context c, Set<String> ids) {
        p(c).edit().putStringSet("cals", new HashSet<>(ids)).apply();
    }

    // ---------- Auto-Bluetooth (Auto-Start) ----------

    static String carAddress(Context c) { return p(c).getString("carAddr", ""); }
    static String carName(Context c) { return p(c).getString("carName", ""); }

    static void setCar(Context c, String addr, String name) {
        p(c).edit().putString("carAddr", addr == null ? "" : addr)
                .putString("carName", name == null ? "" : name).apply();
    }

    // ---------- Fahrzeug ----------

    static String kennzeichen(Context c) { return p(c).getString("kennzeichen", ""); }
    static String fahrer(Context c) { return p(c).getString("fahrer", ""); }

    // ---------- Backup ----------

    static String backupJson(Context c) throws Exception {
        JSONObject o = new JSONObject();
        JSONArray a = new JSONArray();
        for (Trip t : load(c)) a.put(t.toJson());
        o.put("fahrten", a);
        o.put("version", 1);
        JSONObject s = new JSONObject();
        double km = kmPrecise(c);
        if (!Double.isNaN(km)) s.put("kmPrecise", km);
        s.put("kennzeichen", kennzeichen(c));
        s.put("fahrer", fahrer(c));
        for (String key : new String[]{"home", "office"}) {
            double[] pl = place(c, key);
            if (pl != null) {
                s.put(key + "Lat", pl[0]);
                s.put(key + "Lon", pl[1]);
                s.put(key + "Addr", placeAddr(c, key));
            }
        }
        o.put("einstellungen", s);
        return o.toString(1);
    }

    static int restoreJson(Context c, String json) throws Exception {
        JSONObject o = new JSONObject(json);
        JSONArray a = o.getJSONArray("fahrten");
        List<Trip> list = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) list.add(Trip.fromJson(a.getJSONObject(i)));
        save(c, list);
        JSONObject s = o.optJSONObject("einstellungen");
        if (s != null) {
            if (s.has("kmPrecise")) setKmPrecise(c, s.getDouble("kmPrecise"));
            p(c).edit().putString("kennzeichen", s.optString("kennzeichen", ""))
                    .putString("fahrer", s.optString("fahrer", "")).apply();
            for (String key : new String[]{"home", "office"}) {
                if (s.has(key + "Lat")) setPlace(c, key, s.getDouble(key + "Lat"),
                        s.getDouble(key + "Lon"), s.optString(key + "Addr", ""));
            }
        }
        return list.size();
    }
}
