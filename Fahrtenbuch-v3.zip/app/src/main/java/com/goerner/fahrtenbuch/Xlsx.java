package com.goerner.fahrtenbuch;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Kleiner, abhängigkeitsfreier Schreiber für echte Excel-Dateien (.xlsx).
 * Unterstützt: mehrere Blätter, Formate, Rahmen, Farben, Formeln, Spaltenbreiten,
 * fixierte Kopfzeile, Filter, Druckeinstellungen (A4 quer, auf Seitenbreite).
 */
public class Xlsx {

    // ---------- Formate (Index in cellXfs) ----------
    public static final int TITLE = 1, SUB = 2, HEAD = 3;
    public static final int TEXT = 0, INT = 1, DATE = 2, TIME = 3, DEC = 4, PCT = 5;
    public static final int NORMAL = 0, YELLOW = 1, STORNO = 2;
    public static final int SUM_LABEL = 22, SUM_INT = 23, SUM_PCT = 24, NOTE = 25, BOLD = 26;

    /** Zellformat für eine Datenzeile: Variante (NORMAL/YELLOW/STORNO) × Art (TEXT/INT/...). */
    public static int data(int variant, int kind) {
        return 4 + variant * 6 + kind;
    }

    static class Cell {
        String str;        // Text
        Double num;        // Zahl bzw. zwischengespeichertes Formelergebnis
        String formula;
        int style;
    }

    public static class Sheet {
        final String name;
        final TreeMap<Integer, TreeMap<Integer, Cell>> rows = new TreeMap<>();
        final TreeMap<Integer, Double> heights = new TreeMap<>();
        double[] widths = new double[0];
        int freezeRows = 0;
        String autoFilter;       // z. B. "A4:P20"
        String printTitleRows;   // z. B. "$4:$4"
        boolean landscape = true;
        String footerLeft = "";

        Sheet(String name) {
            this.name = name;
        }

        private Cell cell(int r, int c, int style) {
            Cell x = new Cell();
            x.style = style;
            rows.computeIfAbsent(r, k -> new TreeMap<>()).put(c, x);
            return x;
        }

        public void str(int r, int c, String s, int style) {
            cell(r, c, style).str = s == null ? "" : s;
        }

        public void num(int r, int c, double v, int style) {
            cell(r, c, style).num = v;
        }

        public void blank(int r, int c, int style) {
            cell(r, c, style);
        }

        public void formula(int r, int c, String f, double cached, int style) {
            Cell x = cell(r, c, style);
            x.formula = f;
            x.num = cached;
        }

        public void height(int r, double pt) {
            heights.put(r, pt);
        }
    }

    private final List<Sheet> sheets = new ArrayList<>();
    private String creator = "";

    public Sheet sheet(String name) {
        Sheet s = new Sheet(name);
        sheets.add(s);
        return s;
    }

    public void creator(String c) {
        creator = c == null ? "" : c;
    }

    /** Spaltennummer (1 = A) -> Buchstaben. */
    public static String col(int c) {
        StringBuilder sb = new StringBuilder();
        while (c > 0) {
            int m = (c - 1) % 26;
            sb.insert(0, (char) ('A' + m));
            c = (c - 1) / 26;
        }
        return sb.toString();
    }

    public static String ref(int r, int c) {
        return col(c) + r;
    }

    /** Blattname für Formeln: 'Nov 2026' */
    public static String q(String sheet) {
        return "'" + sheet.replace("'", "''") + "'";
    }

    // ======================= Schreiben =======================

    public byte[] build() throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(bo)) {
            put(z, "[Content_Types].xml", contentTypes());
            put(z, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                    + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                    + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
                    + "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>"
                    + "</Relationships>");
            put(z, "docProps/core.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" "
                    + "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" "
                    + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                    + "<dc:title>Fahrtenbuch</dc:title><dc:creator>" + esc(creator) + "</dc:creator></cp:coreProperties>");
            put(z, "docProps/app.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\">"
                    + "<Application>Fahrtenbuch-App</Application></Properties>");
            put(z, "xl/workbook.xml", workbook());
            put(z, "xl/_rels/workbook.xml.rels", workbookRels());
            put(z, "xl/styles.xml", styles());
            for (int i = 0; i < sheets.size(); i++) {
                put(z, "xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml(sheets.get(i), i == 0));
            }
        }
        return bo.toByteArray();
    }

    private static void put(ZipOutputStream z, String name, String content) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    private String contentTypes() {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
                + "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>"
                + "<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>");
        for (int i = 1; i <= sheets.size(); i++) {
            sb.append("<Override PartName=\"/xl/worksheets/sheet").append(i)
                    .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        }
        return sb.append("</Types>").toString();
    }

    private String workbook() {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
                + "<bookViews><workbookView activeTab=\"0\"/></bookViews><sheets>");
        for (int i = 0; i < sheets.size(); i++) {
            sb.append("<sheet name=\"").append(esc(sheets.get(i).name)).append("\" sheetId=\"").append(i + 1)
                    .append("\" r:id=\"rId").append(i + 1).append("\"/>");
        }
        sb.append("</sheets>");
        StringBuilder dn = new StringBuilder();
        for (int i = 0; i < sheets.size(); i++) {
            Sheet s = sheets.get(i);
            if (s.autoFilter != null) {
                String[] p = s.autoFilter.split(":");
                dn.append("<definedName name=\"_xlnm._FilterDatabase\" localSheetId=\"").append(i)
                        .append("\" hidden=\"1\">").append(esc(q(s.name))).append("!").append(abs(p[0]))
                        .append(":").append(abs(p[1])).append("</definedName>");
            }
            if (s.printTitleRows != null) {
                dn.append("<definedName name=\"_xlnm.Print_Titles\" localSheetId=\"").append(i).append("\">")
                        .append(esc(q(s.name))).append("!").append(s.printTitleRows).append("</definedName>");
            }
        }
        if (dn.length() > 0) sb.append("<definedNames>").append(dn).append("</definedNames>");
        sb.append("<calcPr calcId=\"191029\" fullCalcOnLoad=\"1\"/></workbook>");
        return sb.toString();
    }

    private static String abs(String cellRef) {
        int i = 0;
        while (i < cellRef.length() && Character.isLetter(cellRef.charAt(i))) i++;
        return "$" + cellRef.substring(0, i) + "$" + cellRef.substring(i);
    }

    private String workbookRels() {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (int i = 1; i <= sheets.size(); i++) {
            sb.append("<Relationship Id=\"rId").append(i)
                    .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
                    .append(i).append(".xml\"/>");
        }
        sb.append("<Relationship Id=\"rId").append(sheets.size() + 1)
                .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
        return sb.append("</Relationships>").toString();
    }

    private String sheetXml(Sheet s, boolean selected) {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
                + "<sheetPr><pageSetUpPr fitToPage=\"1\"/></sheetPr>");
        sb.append("<sheetViews><sheetView workbookViewId=\"0\"").append(selected ? " tabSelected=\"1\"" : "").append(">");
        if (s.freezeRows > 0) {
            String tl = "A" + (s.freezeRows + 1);
            sb.append("<pane ySplit=\"").append(s.freezeRows).append("\" topLeftCell=\"").append(tl)
                    .append("\" activePane=\"bottomLeft\" state=\"frozen\"/><selection pane=\"bottomLeft\" activeCell=\"")
                    .append(tl).append("\" sqref=\"").append(tl).append("\"/>");
        }
        sb.append("</sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"14\"/>");
        if (s.widths.length > 0) {
            sb.append("<cols>");
            for (int i = 0; i < s.widths.length; i++) {
                sb.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1).append("\" width=\"")
                        .append(String.format(Locale.US, "%.1f", s.widths[i])).append("\" customWidth=\"1\"/>");
            }
            sb.append("</cols>");
        }
        sb.append("<sheetData>");
        for (Integer r : s.rows.keySet()) {
            sb.append("<row r=\"").append(r).append("\"");
            Double h = s.heights.get(r);
            if (h != null) sb.append(" ht=\"").append(String.format(Locale.US, "%.1f", h)).append("\" customHeight=\"1\"");
            sb.append(">");
            for (java.util.Map.Entry<Integer, Cell> e : s.rows.get(r).entrySet()) {
                Cell c = e.getValue();
                String ref = ref(r, e.getKey());
                sb.append("<c r=\"").append(ref).append("\" s=\"").append(c.style).append("\"");
                if (c.formula != null) {
                    sb.append("><f>").append(esc(c.formula)).append("</f>");
                    if (c.num != null) sb.append("<v>").append(numStr(c.num)).append("</v>");
                    sb.append("</c>");
                } else if (c.str != null) {
                    sb.append(" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(c.str)).append("</t></is></c>");
                } else if (c.num != null) {
                    sb.append("><v>").append(numStr(c.num)).append("</v></c>");
                } else {
                    sb.append("/>");
                }
            }
            sb.append("</row>");
        }
        sb.append("</sheetData>");
        if (s.autoFilter != null) sb.append("<autoFilter ref=\"").append(s.autoFilter).append("\"/>");
        sb.append("<printOptions gridLines=\"0\"/>")
                .append("<pageMargins left=\"0.4\" right=\"0.4\" top=\"0.6\" bottom=\"0.6\" header=\"0.3\" footer=\"0.3\"/>")
                .append("<pageSetup paperSize=\"9\" orientation=\"").append(s.landscape ? "landscape" : "portrait")
                .append("\" fitToWidth=\"1\" fitToHeight=\"0\"/>")
                .append("<headerFooter><oddFooter>&amp;L").append(esc(s.footerLeft.replace("&", "&&")))
                .append("&amp;C&amp;A&amp;RSeite &amp;P von &amp;N</oddFooter></headerFooter>");
        return sb.append("</worksheet>").toString();
    }

    private static String numStr(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return String.valueOf((long) v);
        return String.format(Locale.US, "%.10f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    static String esc(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '&': sb.append("&amp;"); break;
                case '<': sb.append("&lt;"); break;
                case '>': sb.append("&gt;"); break;
                case '"': sb.append("&quot;"); break;
                default:
                    if (ch < 0x20 && ch != '\t' && ch != '\n' && ch != '\r') continue; // in XML verboten
                    sb.append(ch);
            }
        }
        return sb.toString();
    }

    // ======================= Formatvorlagen =======================

    private static String styles() {
        StringBuilder x = new StringBuilder();
        // 0 Standard
        x.append(xf(0, 0, 0, 0, null));
        // 1 Titel, 2 Untertitel, 3 Kopfzeile
        x.append(xf(0, 2, 0, 0, null));
        x.append(xf(0, 3, 0, 0, null));
        x.append(xf(0, 4, 2, 1, "<alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/>"));
        // 4..21 Datenzellen: Variante (normal, gelb, storniert) × Art (Text, Ganzzahl, Datum, Uhrzeit, Dezimal, Prozent)
        int[][] variants = {{0, 0}, {0, 4}, {5, 0}}; // {font, fill}
        int[] fmts = {0, 3, 164, 165, 166, 167};
        for (int[] v : variants) {
            for (int k = 0; k < fmts.length; k++) {
                String al = k == 0 ? "<alignment vertical=\"top\" wrapText=\"1\"/>"
                        : "<alignment horizontal=\"" + (k == 2 || k == 3 ? "center" : "right") + "\" vertical=\"top\"/>";
                x.append(xf(fmts[k], v[0], v[1], 1, al));
            }
        }
        // 22 Summe-Text, 23 Summe-Zahl, 24 Summe-Prozent, 25 Hinweis, 26 fett
        x.append(xf(0, 1, 3, 1, "<alignment vertical=\"center\"/>"));
        x.append(xf(3, 1, 3, 1, "<alignment horizontal=\"right\" vertical=\"center\"/>"));
        x.append(xf(167, 1, 3, 1, "<alignment horizontal=\"right\" vertical=\"center\"/>"));
        x.append(xf(0, 6, 0, 0, null));
        x.append(xf(0, 1, 0, 0, null));

        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<numFmts count=\"4\"><numFmt numFmtId=\"164\" formatCode=\"dd.mm.yyyy\"/>"
                + "<numFmt numFmtId=\"165\" formatCode=\"hh:mm\"/><numFmt numFmtId=\"166\" formatCode=\"0.0\"/>"
                + "<numFmt numFmtId=\"167\" formatCode=\"0.0%\"/></numFmts>"
                + "<fonts count=\"7\">"
                + "<font><sz val=\"10\"/><name val=\"Arial\"/><family val=\"2\"/></font>"
                + "<font><b/><sz val=\"10\"/><name val=\"Arial\"/><family val=\"2\"/></font>"
                + "<font><b/><sz val=\"14\"/><color rgb=\"FF1F3A5F\"/><name val=\"Arial\"/><family val=\"2\"/></font>"
                + "<font><sz val=\"9\"/><color rgb=\"FF5F6B7A\"/><name val=\"Arial\"/><family val=\"2\"/></font>"
                + "<font><b/><sz val=\"10\"/><color rgb=\"FFFFFFFF\"/><name val=\"Arial\"/><family val=\"2\"/></font>"
                + "<font><strike/><sz val=\"10\"/><color rgb=\"FF8A94A3\"/><name val=\"Arial\"/><family val=\"2\"/></font>"
                + "<font><i/><sz val=\"9\"/><color rgb=\"FF5F6B7A\"/><name val=\"Arial\"/><family val=\"2\"/></font>"
                + "</fonts>"
                + "<fills count=\"5\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF1F3A5F\"/><bgColor indexed=\"64\"/></patternFill></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE9EDF2\"/><bgColor indexed=\"64\"/></patternFill></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFFF3C4\"/><bgColor indexed=\"64\"/></patternFill></fill>"
                + "</fills>"
                + "<borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border>"
                + "<border><left style=\"thin\"><color rgb=\"FFBFC6D0\"/></left><right style=\"thin\"><color rgb=\"FFBFC6D0\"/></right>"
                + "<top style=\"thin\"><color rgb=\"FFBFC6D0\"/></top><bottom style=\"thin\"><color rgb=\"FFBFC6D0\"/></bottom><diagonal/></border>"
                + "</borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"27\">" + x + "</cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Standard\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                + "</styleSheet>";
    }

    private static String xf(int numFmt, int font, int fill, int border, String align) {
        StringBuilder sb = new StringBuilder("<xf numFmtId=\"").append(numFmt).append("\" fontId=\"").append(font)
                .append("\" fillId=\"").append(fill).append("\" borderId=\"").append(border).append("\" xfId=\"0\"");
        if (numFmt != 0) sb.append(" applyNumberFormat=\"1\"");
        if (font != 0) sb.append(" applyFont=\"1\"");
        if (fill != 0) sb.append(" applyFill=\"1\"");
        if (border != 0) sb.append(" applyBorder=\"1\"");
        if (align != null) sb.append(" applyAlignment=\"1\">").append(align).append("</xf>");
        else sb.append("/>");
        return sb.toString();
    }
}
