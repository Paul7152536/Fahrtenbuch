package com.goerner.fahrtenbuch;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/**
 * Auto-Start/Stopp: Handy verbindet sich mit dem Auto-Bluetooth -> Fahrt startet.
 * Verbindung bricht ab (Motor aus) -> Fahrt stoppt nach kurzer Wartezeit.
 */
public class BtReceiver extends BroadcastReceiver {
    static final String CHANNEL_AUTO = "auto";
    static final int NOTIF_AUTO = 2;

    @Override
    public void onReceive(Context c, Intent i) {
        String action = i.getAction();
        BluetoothDevice dev = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        String car = Store.carAddress(c);
        if (dev == null || car.isEmpty() || !car.equalsIgnoreCase(dev.getAddress())) return;
        SharedPreferences p = Store.p(c);

        if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
            if (p.getBoolean("active", false)) {
                // kurz weg und wieder da (z. B. an der Ampel ausgegangen) -> weiterfahren
                TrackingService.cancelAutoStop();
                return;
            }
            if (p.getBoolean("finishing", false)) return;
            if (Double.isNaN(Store.kmPrecise(c))) {
                askToStart(c, "Kilometerstand fehlt – bitte einmal in der App eingeben");
                return;
            }
            try {
                c.startForegroundService(new Intent(c, TrackingService.class)
                        .setAction(TrackingService.ACTION_START).putExtra("auto", true));
            } catch (Exception e) {
                // Android hat den Start im Hintergrund verweigert -> Hinweis mit Start-Knopf
                askToStart(c, "Mit dem Auto verbunden – Fahrt starten?");
            }
        } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
            if (p.getBoolean("active", false)) {
                TrackingService.scheduleAutoStop(System.currentTimeMillis());
            }
        }
    }

    static void askToStart(Context c, String text) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        if (nm.getNotificationChannel(CHANNEL_AUTO) == null) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL_AUTO, "Auto erkannt",
                    NotificationManager.IMPORTANCE_HIGH));
        }
        PendingIntent start = PendingIntent.getForegroundService(c, 3,
                new Intent(c, TrackingService.class).setAction(TrackingService.ACTION_START).putExtra("auto", true),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent open = PendingIntent.getActivity(c, 4,
                new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CHANNEL_AUTO)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("Fahrtenbuch")
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "FAHRT STARTEN", start).build())
                .build();
        nm.notify(NOTIF_AUTO, n);
    }
}
