package com.goerner.fahrtenbuch;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;

import java.util.List;
import java.util.Locale;

/** Adressen <-> Koordinaten (ueber den Android-Geocoder, kein API-Schluessel noetig). */
public class Geo {

    /** Koordinaten -> lesbare Adresse, oder null. Blockiert kurz (Netz) – nicht im UI-Thread aufrufen. */
    @SuppressWarnings("deprecation")
    static String reverse(Context c, double lat, double lon) {
        if (Double.isNaN(lat) || Double.isNaN(lon) || !Geocoder.isPresent()) return null;
        try {
            List<Address> l = new Geocoder(c, Locale.GERMANY).getFromLocation(lat, lon, 1);
            if (l != null && !l.isEmpty()) {
                String s = format(l.get(0));
                return s.isEmpty() ? null : s;
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** Adresstext -> {lat, lon}, oder null. Blockiert kurz (Netz). */
    @SuppressWarnings("deprecation")
    static double[] forward(Context c, String text) {
        if (text == null || text.trim().length() < 4 || !Geocoder.isPresent()) return null;
        try {
            List<Address> l = new Geocoder(c, Locale.GERMANY).getFromLocationName(text.trim(), 1);
            if (l != null && !l.isEmpty() && l.get(0).hasLatitude() && l.get(0).hasLongitude()) {
                return new double[]{l.get(0).getLatitude(), l.get(0).getLongitude()};
            }
        } catch (Exception ignored) { }
        return null;
    }

    static String format(Address a) {
        StringBuilder sb = new StringBuilder();
        String street = a.getThoroughfare();
        String no = a.getSubThoroughfare();
        String plz = a.getPostalCode();
        String city = a.getLocality();
        if (street != null) {
            sb.append(street);
            if (no != null) sb.append(' ').append(no);
        }
        if (plz != null || city != null) {
            if (sb.length() > 0) sb.append(", ");
            if (plz != null) sb.append(plz).append(' ');
            if (city != null) sb.append(city);
        }
        String s = sb.toString().trim();
        if (s.isEmpty() && a.getMaxAddressLineIndex() >= 0) s = a.getAddressLine(0);
        return s == null ? "" : s;
    }

    /** Abstand in Metern; unendlich, wenn eine Position fehlt. */
    static double dist(double lat1, double lon1, double lat2, double lon2) {
        if (Double.isNaN(lat1) || Double.isNaN(lon1) || Double.isNaN(lat2) || Double.isNaN(lon2))
            return Double.POSITIVE_INFINITY;
        float[] r = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, r);
        return r[0];
    }

    static boolean near(double[] place, double lat, double lon, double meters) {
        return place != null && dist(place[0], place[1], lat, lon) <= meters;
    }
}
