package com.goerner.fahrtenbuch;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.util.Locale;

/** Läuft während der Fahrt im Vordergrund und zählt die Kilometer per GPS. */
public class TrackingService extends Service implements LocationListener {
    static final String ACTION_START = "com.goerner.fahrtenbuch.START";
    static final String ACTION_STOP = "com.goerner.fahrtenbuch.STOP";
    static final String ACTION_RESUME = "com.goerner.fahrtenbuch.RESUME";
    static final String CHANNEL = "fahrt";
    static final int NOTIF_ID = 1;

    static volatile boolean running = false;
    static final long AUTO_STOP_DELAY = 120_000L; // 2 Min Wartezeit nach Bluetooth-Trennung

    private static TrackingService instance;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static long btOffAt = 0;
    private static final Runnable AUTO_STOP = () -> {
        if (instance != null) instance.stopTrip();
    };

    /** Auto-Bluetooth getrennt: nach Wartezeit stoppen (Ende = Zeitpunkt der Trennung). */
    static void scheduleAutoStop(long when) {
        if (instance == null) return;
        btOffAt = when;
        MAIN.removeCallbacks(AUTO_STOP);
        MAIN.postDelayed(AUTO_STOP, AUTO_STOP_DELAY);
    }

    /** Auto-Bluetooth wieder verbunden: Fahrt läuft weiter. */
    static void cancelAutoStop() {
        btOffAt = 0;
        MAIN.removeCallbacks(AUTO_STOP);
    }

    private LocationManager lm;
    private long lastNotif = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        SharedPreferences p = Store.p(this);

        if (ACTION_STOP.equals(action)) {
            stopTrip();
            return START_NOT_STICKY;
        }

        boolean fresh = false;
        boolean auto = intent != null && intent.getBooleanExtra("auto", false);
        if (ACTION_START.equals(action) && !p.getBoolean("active", false)) {
            fresh = true;
            cancelAutoStop();
            SharedPreferences.Editor e = p.edit();
            e.putBoolean("autoStart", auto);
            e.remove("lastMsg");
            e.putBoolean("active", true);
            e.putLong("tStart", System.currentTimeMillis());
            e.putFloat("dist", 0f);
            for (String k : new String[]{"sLat", "sLon", "eLat", "eLon", "lLat", "lLon"}) e.remove(k);
            e.remove("lTime");
            e.apply();
        }

        if (!p.getBoolean("active", false)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            startForeground(NOTIF_ID, buildNotif(statusText()), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            running = true;
            instance = this;
            NotificationManager nm0 = getSystemService(NotificationManager.class);
            if (nm0 != null) nm0.cancel(BtReceiver.NOTIF_AUTO);
        } catch (Exception ex) {
            // z. B. Start im Hintergrund nicht erlaubt – die App setzt beim Öffnen fort
            running = false;
            if (fresh) {
                p.edit().putBoolean("active", false).apply();
                if (auto) BtReceiver.askToStart(this, "Mit dem Auto verbunden – Fahrt starten?");
            }
            stopSelf();
            return START_NOT_STICKY;
        }
        startLocation();
        return START_STICKY;
    }

    private void startLocation() {
        if (lm != null) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            return;
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (lm == null) return;
        // Startposition sofort aus letzter bekannter Position (falls frisch), bis GPS da ist
        try {
            SharedPreferences p = Store.p(this);
            if (Double.isNaN(Store.getD(p, "sLat"))) {
                Location best = null;
                for (String prov : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                    Location l = lm.getLastKnownLocation(prov);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                }
                if (best != null && System.currentTimeMillis() - best.getTime() < 3 * 60_000L) {
                    SharedPreferences.Editor e = p.edit();
                    Store.putD(e, "sLat", best.getLatitude());
                    Store.putD(e, "sLon", best.getLongitude());
                    e.apply();
                }
            }
        } catch (Exception ignored) { }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 5, this, Looper.getMainLooper());
        } catch (Exception ignored) { }
    }

    @Override
    public void onLocationChanged(Location loc) {
        SharedPreferences p = Store.p(this);
        if (!p.getBoolean("active", false)) return;
        if (loc.hasAccuracy() && loc.getAccuracy() > 40) return;

        SharedPreferences.Editor e = p.edit();
        if (Double.isNaN(Store.getD(p, "sLat")) || loc.getTime() - p.getLong("tStart", 0) < 20_000L
                && p.getFloat("dist", 0f) < 50f) {
            // erste gute Position = Start (in den ersten Sekunden nachbessern)
            Store.putD(e, "sLat", loc.getLatitude());
            Store.putD(e, "sLon", loc.getLongitude());
        }
        Store.putD(e, "eLat", loc.getLatitude());
        Store.putD(e, "eLon", loc.getLongitude());

        double lLat = Store.getD(p, "lLat"), lLon = Store.getD(p, "lLon");
        long lTime = p.getLong("lTime", 0);
        float dist = p.getFloat("dist", 0f);
        if (Double.isNaN(lLat)) {
            Store.putD(e, "lLat", loc.getLatitude());
            Store.putD(e, "lLon", loc.getLongitude());
            e.putLong("lTime", loc.getTime());
        } else {
            float[] r = new float[1];
            Location.distanceBetween(lLat, lLon, loc.getLatitude(), loc.getLongitude(), r);
            float d = r[0];
            long dt = loc.getTime() - lTime;
            boolean plausible = dt <= 0 || d / (dt / 1000f) < 70f; // < 250 km/h
            if (d >= 8 && plausible) {
                dist += d;
                e.putFloat("dist", dist);
                Store.putD(e, "lLat", loc.getLatitude());
                Store.putD(e, "lLon", loc.getLongitude());
                e.putLong("lTime", loc.getTime());
            }
        }
        e.apply();

        long now = System.currentTimeMillis();
        if (now - lastNotif > 10_000L) {
            lastNotif = now;
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(NOTIF_ID, buildNotif(statusText()));
        }
    }

    // Fuer Android 10 noetig (dort sind diese Methoden noch Pflicht)
    @Override public void onProviderEnabled(String provider) { }
    @Override public void onProviderDisabled(String provider) { }
    @SuppressWarnings("deprecation")
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }

    private String statusText() {
        float km = Store.p(this).getFloat("dist", 0f) / 1000f;
        return String.format(Locale.GERMANY, "Fahrt läuft · %.1f km", km);
    }

    private void stopTrip() {
        final SharedPreferences p = Store.p(this);
        if (lm != null) {
            try { lm.removeUpdates(this); } catch (Exception ignored) { }
            lm = null;
        }
        if (!p.getBoolean("active", false)) {
            endService();
            return;
        }
        final long tStart = p.getLong("tStart", System.currentTimeMillis());
        final long tEnd = btOffAt > 0 ? btOffAt : System.currentTimeMillis();
        cancelAutoStop();
        final double sLat = Store.getD(p, "sLat"), sLon = Store.getD(p, "sLon");
        final double eLat = Store.getD(p, "eLat"), eLon = Store.getD(p, "eLon");
        final double dist = p.getFloat("dist", 0f);
        p.edit().putBoolean("active", false).putBoolean("finishing", true).apply();

        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null && running) nm.notify(NOTIF_ID, buildNotif("Fahrt wird gespeichert …"));

        new Thread(() -> {
            String msg;
            try {
                Trip t = TripFinisher.finish(getApplicationContext(), tStart, tEnd, sLat, sLon, eLat, eLon, dist);
                msg = "Gespeichert: " + t.km() + " km → " + t.ziel;
            } catch (Exception ex) {
                msg = "Fehler beim Speichern: " + ex.getMessage();
            }
            p.edit().putBoolean("finishing", false).putString("lastMsg", msg).apply();
            new Handler(Looper.getMainLooper()).post(this::endService);
        }).start();
    }

    private void endService() {
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        running = false;
        if (instance == this) instance = null;
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (lm != null) {
            try { lm.removeUpdates(this); } catch (Exception ignored) { }
            lm = null;
        }
        running = false;
        if (instance == this) instance = null;
        MAIN.removeCallbacks(AUTO_STOP);
        super.onDestroy();
    }

    private Notification buildNotif(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Laufende Fahrt", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent piOpen = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, TrackingService.class).setAction(ACTION_STOP);
        PendingIntent piStop = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("Fahrtenbuch")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(piOpen)
                .addAction(new Notification.Action.Builder(null, "STOPP", piStop).build())
                .build();
    }
}
